# Epic Mafia Bot — modular build
# All bot logic is split into modules/ and loaded into one shared namespace.
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MODULE_DIR = BASE_DIR / "modules"

MODULES = [
    "01_config_roles.py",
    "02_database_hero.py",
    "03_game_core.py",
    "04_lobby_modes.py",
    "05_profile_market.py",
    "06_night_actions.py",
    "07_resolution_day_vote.py",
    "08_admin_panel.py",
    "09_handlers_startup.py",
]

def _load_modules():
    shared = globals()
    for filename in MODULES:
        path = MODULE_DIR / filename
        if not path.is_file():
            raise FileNotFoundError(f"Module topilmadi: {path}")
        source = path.read_text(encoding="utf-8")
        exec(compile(source, str(path), "exec"), shared, shared)

_load_modules()

if __name__=="__main__":
    init_db()
    load_games_state()
    try:
        app=build_app(token())
        resume_games(app)
        log.info("Epic Mafia starting. PTB 20+ polling.")
        app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)
    except Exception as e:
        log.exception("Fatal startup error")
        print(str(e))
