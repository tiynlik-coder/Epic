EPIC MAFIA — MODULAR + ADMIN PANEL

Python: 3.10+
Library: python-telegram-bot 20–22
Run: python main.py

Install:
pip install -r requirements.txt

BOT_TOKEN can be supplied through the environment variable BOT_TOKEN.
If it is not set and the terminal is interactive, main.py asks for it.

ADMIN_ID: 5500951019

Admin features integrated into the same Epic Mafia bot:
- /admin panel
- user block/unblock
- group block/unblock
- /aktiv <role> and /unaktiv (reply to a user)
- forced admin roles are assigned first at game start
- purchased Active Roles are assigned after forced roles and before the remaining role pool
- active-role purchase submenu with role-specific prices adapted from the supplied admin/market file
- currency/inventory management
- statistics, rankings, active games, group search/listing
- broadcast
- VIP list
- hero list/market removal
- admin logs

Blocked users receive no bot response, including private start/menu callbacks.
Blocked groups do not receive gameplay responses; an admin can still /ungblock the group.

The supplied Download.zip's aiogram/Tortoise/PostgreSQL/Redis/MirPay implementation is NOT copied as a runtime dependency. Its admin functionality is adapted to this Epic Mafia PTB + existing SQLite architecture.
