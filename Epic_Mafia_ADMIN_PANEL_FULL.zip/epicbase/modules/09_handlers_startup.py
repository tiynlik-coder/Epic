async def setup_bot_commands(app):
    # Private chat: exactly these three commands.
    await app.bot.set_my_commands([
        BotCommand("start", "Botni qayta ishga tushirish"),
        BotCommand("profile", "Profilni ko‘rish"),
        BotCommand("market", "Market"),
    ], scope=BotCommandScopeAllPrivateChats())

    # Group chat: all gameplay/admin commands supported by the current bot.
    group_commands = [
        BotCommand("start", "Botni qayta ishga tushirish"),
        BotCommand("game", "Oddiy o‘yinni boshlash"),
        BotCommand("ngame", "Name mode"),
        BotCommand("ugame", "Uniform mode"),
        BotCommand("zgame", "Zombie mode"),
        BotCommand("vsgame", "VS mode"),
        BotCommand("vsgame2", "VS — 2 jamoa"),
        BotCommand("vsgame3", "VS — 3 jamoa"),
        BotCommand("vsgame4", "VS — 4 jamoa"),
        BotCommand("vsgame5", "VS — 5 jamoa"),
        BotCommand("vsgame6", "VS — 6 jamoa"),
        BotCommand("vsgame7", "VS — 7 jamoa"),
        BotCommand("vsgame8", "VS — 8 jamoa"),
        BotCommand("vsgame9", "VS — 9 jamoa"),
        BotCommand("bounty", "Bounty qo‘yish"),
        BotCommand("modes", "Mode tanlash"),
        BotCommand("stop", "O‘yinni to‘xtatish"),
        BotCommand("admin", "Admin paneli"),
        BotCommand("aktiv", "Userga doimiy rol biriktirish"),
        BotCommand("unaktiv", "Doimiy rolni olib tashlash"),
        BotCommand("block", "Userni bloklash"),
        BotCommand("unblock", "Userni blokdan chiqarish"),
        BotCommand("gblock", "Guruhni bloklash"),
        BotCommand("ungblock", "Guruhni blokdan chiqarish"),
    ]
    await app.bot.set_my_commands(group_commands, scope=BotCommandScopeAllGroupChats())

async def error_handler(update,ctx): log.exception("Unhandled error",exc_info=ctx.error)

def token():
    t=os.getenv("BOT_TOKEN")
    if t:return t.strip()
    if sys.stdin.isatty():
        t=input("BOT_TOKEN kiriting: ").strip()
        if t:return t
    raise RuntimeError("BOT_TOKEN topilmadi. Replit Secrets bo‘limiga BOT_TOKEN nomi bilan bot tokeningizni kiriting.")

def build_app(t):
    app=ApplicationBuilder().token(t).post_init(setup_bot_commands).build()
    app.add_handler(CommandHandler("start",cmd_start))
    app.add_handler(CommandHandler("game",cmd_game))
    app.add_handler(CommandHandler("ngame",cmd_ngame))
    app.add_handler(CommandHandler("ugame",cmd_ugame))
    app.add_handler(CommandHandler("zgame",cmd_zgame))
    app.add_handler(CommandHandler("vsgame",cmd_vsgame))
    for _n in range(2,10):
        app.add_handler(CommandHandler(f"vsgame{_n}", lambda update, ctx, n=_n: cmd_vsgame(update,ctx,n)))
    app.add_handler(CommandHandler("bounty",cmd_bounty))
    app.add_handler(CommandHandler("modes",cmd_modes))
    app.add_handler(CommandHandler("stop",cmd_stop))
    app.add_handler(CommandHandler("profile",cmd_profile))
    app.add_handler(CommandHandler("market",cmd_market))
    app.add_handler(CommandHandler("admin",cmd_admin))
    # Admin panel callbacks and hard block guards run before normal handlers.
    app.add_handler(MessageHandler(filters.ALL, admin_guard_message), group=-100)
    app.add_handler(CallbackQueryHandler(admin_guard_callback), group=-100)
    app.add_handler(CommandHandler("aktiv",cmd_aktiv))
    app.add_handler(CommandHandler("unaktiv",cmd_unaktiv))
    app.add_handler(CommandHandler("block",cmd_block))
    app.add_handler(CommandHandler("unblock",cmd_unblock))
    app.add_handler(CommandHandler("gblock",cmd_gblock))
    app.add_handler(CommandHandler("ungblock",cmd_gunblock))
    app.add_handler(CommandHandler("checkuser",cmd_checkuser))
    app.add_handler(CommandHandler("inventory",cmd_inventory))
    app.add_handler(CommandHandler("pul",cmd_pul))
    app.add_handler(CommandHandler("olmos",cmd_olmos))
    app.add_handler(CommandHandler("coin",cmd_coin))
    app.add_handler(CommandHandler("bust",cmd_bust))
    app.add_handler(CommandHandler("blocks",cmd_blocks))
    app.add_handler(CommandHandler("id",cmd_id))
    app.add_handler(CommandHandler("gsearch",cmd_gsearch))
    app.add_handler(CommandHandler("groups",cmd_groups))
    app.add_handler(CommandHandler("active",cmd_active_games))
    app.add_handler(CommandHandler("checkgaming",cmd_checkgaming))
    app.add_handler(CommandHandler("stopgames",cmd_stopgames))
    app.add_handler(CommandHandler("stats",cmd_stats))
    app.add_handler(CommandHandler("top",cmd_top))
    app.add_handler(CommandHandler("gtop",cmd_top))
    app.add_handler(CommandHandler("gboylar",cmd_top))
    app.add_handler(CommandHandler("eboylar",cmd_top))
    app.add_handler(CommandHandler("tchat",cmd_stats))
    app.add_handler(CommandHandler("tchats",cmd_stats))
    app.add_handler(CommandHandler("tchat1",cmd_stats))
    app.add_handler(CommandHandler("tchat7",cmd_stats))
    app.add_handler(CommandHandler("tchat30",cmd_stats))
    app.add_handler(CommandHandler("geroys",cmd_heroes))
    app.add_handler(CommandHandler("rgm",cmd_rgm))
    app.add_handler(CommandHandler("vip",cmd_vip))
    app.add_handler(CommandHandler("unvip",cmd_unvip))
    app.add_handler(CommandHandler("broadcast",cmd_broadcast))
    app.add_handler(CommandHandler("zapravka1",cmd_zapravka1))
    app.add_handler(CommandHandler("zapravka7",cmd_zapravka7))
    app.add_handler(CallbackQueryHandler(admin_callback, pattern=r"^admin:"))
    app.add_handler(CallbackQueryHandler(cb_active_role, pattern=r"^ar:"))
    app.add_handler(CallbackQueryHandler(cb_join,r"^join:"))
    app.add_handler(CallbackQueryHandler(cb_mode,r"^mode:"))
    app.add_handler(CallbackQueryHandler(cb_action,r"^act:"))
    app.add_handler(CallbackQueryHandler(cb_manip2,r"^manip2:"))
    app.add_handler(CallbackQueryHandler(cb_res,r"^res:"))
    app.add_handler(CallbackQueryHandler(cb_zombie,r"^zombie:"))
    app.add_handler(CallbackQueryHandler(cb_katani_mode,r"^katani_mode:"))
    app.add_handler(CallbackQueryHandler(cb_katani,r"^katani:"))
    app.add_handler(CallbackQueryHandler(cb_prof,r"^prof:"))
    app.add_handler(CallbackQueryHandler(cb_prof_target,r"^prof_target:"))
    app.add_handler(CallbackQueryHandler(cb_vey1,r"^vey1:"))
    app.add_handler(CallbackQueryHandler(cb_vey2,r"^vey2:"))
    app.add_handler(CallbackQueryHandler(cb_menu,r"^menu:"))
    app.add_handler(CallbackQueryHandler(cb_role,r"^role:\d+$"))
    app.add_handler(CallbackQueryHandler(hero_callback,r"^hero:"))
    app.add_handler(CallbackQueryHandler(cb_heroact,r"^heroact:"))
    app.add_handler(CallbackQueryHandler(cb_buy,r"^buy:"))
    app.add_handler(MessageHandler(filters.TEXT & filters.ChatType.PRIVATE & ~filters.COMMAND, admin_text_handler), group=1)
    app.add_handler(MessageHandler(filters.TEXT & filters.ChatType.PRIVATE & ~filters.COMMAND, hero_private_text), group=2)
    app.add_handler(CallbackQueryHandler(cb_vote,r"^(vote|skip):"))
    app.add_handler(CallbackQueryHandler(cb_af,r"^af:"))
    app.add_handler(CallbackQueryHandler(cb_folbin_msg,r"^(read_f|cancel_f):"))
    app.add_error_handler(error_handler)
    return app

if __name__=="__main__":
    init_db()
    load_games_state()
    try:
        app=build_app(token())
        resume_games(app)
        log.info("Epic Mafia starting. PTB 20+ polling.")
        app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=True)
    except Exception as e:
        log.exception("Fatal startup error")
        print(str(e))
