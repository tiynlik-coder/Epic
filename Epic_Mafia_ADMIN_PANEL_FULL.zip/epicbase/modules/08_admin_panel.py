# Epic Mafia — integrated admin panel
# Adapted from the supplied Download.zip admin feature set, using Epic Mafia's
# existing SQLite data store and python-telegram-bot architecture.

from telegram.ext import ApplicationHandlerStop
from datetime import datetime

# ---------------- ADMIN DATA ----------------
ADMIN_ACTIVE_ROLE_PRICES = {
    "Minior": (6, "diamonds"),
    "Sotqin": (4, "diamonds"),
    "Qorbobo": (4, "diamonds"),
    "Komissar Katani": (2, "diamonds"),
    "Don": (2, "diamonds"),
    "Qotil": (2, "diamonds"),
    "Labarant": (2, "diamonds"),
    "Koldun": (2, "diamonds"),
    "Mafia": (1, "diamonds"),
    "Serjant": (1, "diamonds"),
    "Shifokor": (600, "money"),
    "Kezuvchi": (500, "money"),
    "Advokat": (500, "money"),
    "Afsungar": (500, "money"),
    "Daydi": (400, "money"),
    "Suidsid": (300, "money"),
    "Ayg‘oqchi": (300, "money"),
    "Tinch axoli": (100, "money"),
}

_ADMIN_ROLE_ALIASES = {}
for _r in ROLES:
    _ADMIN_ROLE_ALIASES[_r.lower().replace("’", "'")] = _r
_ADMIN_ROLE_ALIASES.update({
    "doktor": "Shifokor", "doctor": "Shifokor", "komissar": "Komissar Katani",
    "katani": "Komissar Katani", "citizen": "Tinch axoli", "fuqaro": "Tinch axoli",
})


def _admin_db_init():
    con = db()
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_blocked_users(
        user_id INTEGER PRIMARY KEY, reason TEXT DEFAULT '', created_at REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_blocked_groups(
        chat_id INTEGER PRIMARY KEY, title TEXT DEFAULT '', created_at REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_known_groups(
        chat_id INTEGER PRIMARY KEY, title TEXT DEFAULT '', username TEXT DEFAULT '',
        type TEXT DEFAULT '', last_seen REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_forced_roles(
        user_id INTEGER PRIMARY KEY, role TEXT NOT NULL, set_by INTEGER NOT NULL, created_at REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_active_roles(
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, role TEXT NOT NULL,
        is_active INTEGER DEFAULT 1, created_at REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_vips(
        user_id INTEGER PRIMARY KEY, created_at REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS admin_logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER, action TEXT, target TEXT DEFAULT '', created_at REAL DEFAULT 0
    )""")
    con.commit(); con.close()


def admin_log(action, target=""):
    try:
        con=db(); con.execute("INSERT INTO admin_logs(admin_id,action,target,created_at) VALUES(?,?,?,?)",(ADMIN_ID,action,str(target),time.time())); con.commit(); con.close()
    except Exception: pass


def _blocked_user(uid):
    con=db(); r=con.execute("SELECT 1 FROM admin_blocked_users WHERE user_id=?",(int(uid),)).fetchone(); con.close(); return bool(r)


def _blocked_group(cid):
    con=db(); r=con.execute("SELECT 1 FROM admin_blocked_groups WHERE chat_id=?",(int(cid),)).fetchone(); con.close(); return bool(r)


def _register_group(chat):
    if not chat or chat.type not in {ChatType.GROUP, ChatType.SUPERGROUP}: return
    try:
        con=db(); con.execute("INSERT INTO admin_known_groups(chat_id,title,username,type,last_seen) VALUES(?,?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title,username=excluded.username,type=excluded.type,last_seen=excluded.last_seen",(chat.id,chat.title or '',getattr(chat,'username','') or '',chat.type,time.time())); con.commit(); con.close()
    except Exception: pass

async def admin_guard_message(update, ctx):
    u=update.effective_user; c=update.effective_chat
    if c and c.type in {ChatType.GROUP, ChatType.SUPERGROUP}:
        _register_group(c)
        if u and u.id != ADMIN_ID and (_blocked_group(c.id) or _blocked_user(u.id)):
            raise ApplicationHandlerStop
    elif u and u.id != ADMIN_ID and _blocked_user(u.id):
        raise ApplicationHandlerStop

async def admin_guard_callback(update, ctx):
    q=update.callback_query; u=q.from_user if q else None; c=q.message.chat if q and q.message else None
    if c and c.type in {ChatType.GROUP, ChatType.SUPERGROUP} and u and u.id != ADMIN_ID and (_blocked_group(c.id) or _blocked_user(u.id)):
        await q.answer("🚫 Siz uchun bu funksiya bloklangan.", show_alert=True)
        raise ApplicationHandlerStop
    if u and u.id != ADMIN_ID and _blocked_user(u.id):
        await q.answer("🚫 Siz botdan bloklangansiz.", show_alert=True)
        raise ApplicationHandlerStop


def _admin_only(update):
    return bool(update.effective_user and update.effective_user.id == ADMIN_ID)


def _role_from_text(raw):
    s=(raw or '').strip().lower().replace('’',"'").replace('`',"'")
    # Allow an emoji before the role name.
    for r in sorted(ROLES, key=len, reverse=True):
        if s == r.lower().replace('’',"'") or s.endswith(" "+r.lower().replace('’',"'")):
            return r
    return _ADMIN_ROLE_ALIASES.get(s)


def forced_role(uid):
    con=db(); r=con.execute("SELECT role FROM admin_forced_roles WHERE user_id=?",(int(uid),)).fetchone(); con.close(); return r[0] if r else None


def active_roles_for(uid, only_active=True):
    con=db(); q="SELECT id,role,created_at FROM admin_active_roles WHERE user_id=?" + (" AND is_active=1" if only_active else "") + " ORDER BY created_at,id"; rows=con.execute(q,(int(uid),)).fetchall(); con.close(); return rows


def apply_admin_roles(g, role_list):
    """Assignment order: admin-forced roles first, then purchased active roles, then remaining roles."""
    players=list(g.get("players",{}).values())
    assigned={}
    used_role_indices=set()
    used_active_ids=[]

    # 1) Forced admin roles always win over the random pool.
    for p in players:
        r=forced_role(p["id"])
        if not r: continue
        assigned[p["id"]]=r
        # Consume one matching random slot if available; otherwise replace a later slot.
        try:
            idx=next(i for i,x in enumerate(role_list) if i not in used_role_indices and x==r)
            used_role_indices.add(idx)
        except StopIteration:
            pass

    # 2) Purchased active roles: use the first active role whose role exists in the pool.
    # Do not apply to a player that already has an admin-forced role.
    remaining_indices=[i for i in range(len(role_list)) if i not in used_role_indices]
    for p in players:
        if p["id"] in assigned: continue
        ars=active_roles_for(p["id"])
        chosen=None
        chosen_idx=None
        for ar in ars:
            for idx in remaining_indices:
                if role_list[idx]==ar[1]:
                    chosen=(ar[1],ar[0]); chosen_idx=idx; break
            if chosen: break
        if chosen:
            assigned[p["id"]]=chosen[0]
            used_role_indices.add(chosen_idx)
            remaining_indices.remove(chosen_idx)
            used_active_ids.append(chosen[1])

    # 3) Fill unassigned players with all remaining roles in stable shuffled order.
    remaining_roles=[r for i,r in enumerate(role_list) if i not in used_role_indices]
    random.shuffle(remaining_roles)
    for p in players:
        if p["id"] not in assigned and remaining_roles:
            assigned[p["id"]]=remaining_roles.pop(0)

    # If forced roles replaced slots, make sure every player still gets a role.
    while remaining_roles and len(assigned)<len(players):
        for p in players:
            if p["id"] not in assigned:
                assigned[p["id"]]=remaining_roles.pop(0); break
    while len(assigned)<len(players):
        for p in players:
            if p["id"] not in assigned:
                assigned[p["id"]]="Tinch axoli"; break

    if used_active_ids:
        con=db(); con.executemany("UPDATE admin_active_roles SET is_active=0 WHERE id=?",[(int(x),) for x in used_active_ids]); con.commit(); con.close()
    return [assigned[p["id"]] for p in players]


# ---------------- ACTIVE ROLE MARKET ----------------
def active_role_market_markup():
    rows=[]
    for role,(price,currency) in ADMIN_ACTIVE_ROLE_PRICES.items():
        symbol='💎' if currency=='diamonds' else '💷'
        rows.append([InlineKeyboardButton(f"{EMOJI.get(role,'🎭')} {role} — {price}{symbol}",callback_data=f"ar:buy:{role}")])
    rows.append([InlineKeyboardButton("🗑 Faol rolni o‘chirish — 100💷",callback_data="ar:delete")])
    rows.append([InlineKeyboardButton("🔙 Orqaga",callback_data="ar:back")])
    return InlineKeyboardMarkup(rows)


def active_role_text(uid):
    rows=active_roles_for(uid)
    if not rows: current="🃏 Faol rollar: yo‘q"
    else: current="🃏 <b>Faol rollar:</b>\n"+"\n".join(f"• {EMOJI.get(r[1],'🎭')} {html.escape(r[1])}" for r in rows)
    return "🎭 <b>Faol rol</b>\n\nSotib olingan rol keyingi mos o‘yinda birinchi navbatda beriladi.\n\n"+current

async def cb_active_role(update,ctx):
    q=update.callback_query; a=q.data.split(":",2); uid=q.from_user.id
    if q.message.chat.type!=ChatType.PRIVATE: return await cb_answer(q,"Faqat shaxsiy chatda.",True)
    if a[1]=='back':
        return await send_market(q.message)
    if a[1]=='delete':
        con=db(); r=con.execute("SELECT id,role FROM admin_active_roles WHERE user_id=? AND is_active=1 ORDER BY created_at,id LIMIT 1",(uid,)).fetchone()
        bal=con.execute("SELECT money FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r: con.close(); return await cb_answer(q,"❌ Sizda faol rol yo‘q!",True)
        if not bal or int(bal[0])<100: con.close(); return await cb_answer(q,"❌ Mablag‘ yetarli emas.",True)
        con.execute("UPDATE users SET money=money-100 WHERE user_id=?",(uid,)); con.execute("UPDATE admin_active_roles SET is_active=0 WHERE id=?",(r[0],)); con.commit(); con.close()
        return await safe_edit(q,active_role_text(uid),active_role_market_markup())
    if a[1]=='buy':
        role=a[2]
        if role not in ADMIN_ACTIVE_ROLE_PRICES: return await cb_answer(q,"❌ Bu rol mavjud emas.",True)
        price,currency=ADMIN_ACTIVE_ROLE_PRICES[role]
        # Prevent duplicate active copies of the same role for one user.
        con=db(); exists=con.execute("SELECT 1 FROM admin_active_roles WHERE user_id=? AND role=? AND is_active=1",(uid,role)).fetchone(); con.close()
        if exists: return await cb_answer(q,"❌ Bu faol rol sizda allaqachon bor.",True)
        ok,msg=buy(uid,"active_role","money",0) if False else (False,"")
        con=db()
        try:
            con.execute("BEGIN IMMEDIATE")
            row=con.execute(f"SELECT {currency} FROM users WHERE user_id=?",(uid,)).fetchone()
            if not row or int(row[0] or 0)<price:
                con.rollback(); return await cb_answer(q,f"❌ Sizda yetarli {'💎' if currency=='diamonds' else '💷'} mavjud emas.",True)
            con.execute(f"UPDATE users SET {currency}={currency}-? WHERE user_id=?",(price,uid))
            con.execute("INSERT INTO admin_active_roles(user_id,role,is_active,created_at) VALUES(?,?,1,?)",(uid,role,time.time()))
            con.commit()
        finally: con.close()
        return await safe_edit(q,active_role_text(uid),active_role_market_markup())
    return await cb_answer(q)


# ---------------- ADMIN PANEL UI ----------------
def admin_menu_markup():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Statistika",callback_data="admin:stats"),InlineKeyboardButton("👥 Userlar",callback_data="admin:users")],
        [InlineKeyboardButton("🏠 Guruhlar",callback_data="admin:groups"),InlineKeyboardButton("🎮 O‘yinlar",callback_data="admin:games")],
        [InlineKeyboardButton("🚫 Bloklar",callback_data="admin:blocks"),InlineKeyboardButton("🎭 Aktiv rollar",callback_data="admin:active")],
        [InlineKeyboardButton("💰 Valyuta / Inventar",callback_data="admin:money"),InlineKeyboardButton("🥷 Geroylar",callback_data="admin:heroes")],
        [InlineKeyboardButton("🌟 VIP",callback_data="admin:vips"),InlineKeyboardButton("📝 Loglar",callback_data="admin:logs")],
        [InlineKeyboardButton("📢 Broadcast",callback_data="admin:broadcast")],
    ])

async def cmd_admin(update,ctx):
    if not _admin_only(update): return
    if update.effective_chat.type!=ChatType.PRIVATE:
        return await update.message.reply_text("⚙️ Admin paneli shaxsiy chatda ishlaydi. /admin ni botga PMda yuboring.")
    _admin_db_init(); admin_log("open_panel")
    await update.message.reply_text("🛠 <b>Epic Mafia Admin Panel</b>\n\nKerakli bo‘limni tanlang:",reply_markup=admin_menu_markup())

async def admin_callback(update,ctx):
    q=update.callback_query
    if q.from_user.id!=ADMIN_ID: return await cb_answer(q,"Ruxsat yo‘q.",True)
    await cb_answer(q)
    key=q.data.split(":",1)[1]
    if key=='home': return await safe_edit(q,"🛠 <b>Epic Mafia Admin Panel</b>",admin_menu_markup())
    if key=='stats':
        con=db(); u=con.execute("SELECT COUNT(*) c FROM users").fetchone()[0]; g=len([x for x in games.values() if x.get('phase') not in {'ended','cancelled'}]); blocked_u=con.execute("SELECT COUNT(*) c FROM admin_blocked_users").fetchone()[0]; blocked_g=con.execute("SELECT COUNT(*) c FROM admin_blocked_groups").fetchone()[0]; con.close()
        return await safe_edit(q,f"📊 <b>Statistika</b>\n\n👥 Userlar: {u}\n🎮 Faol o‘yinlar: {g}\n🚫 Bloklangan userlar: {blocked_u}\n🚫 Bloklangan guruhlar: {blocked_g}",InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='users':
        return await safe_edit(q,"👥 <b>User boshqaruvi</b>\n\nID yuborish uchun quyidagi buyruqlardan foydalaning:\n/checkuser ID\n/block ID\n/unblock ID\n/bust ID",InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='groups':
        return await safe_edit(q,"🏠 <b>Guruh boshqaruvi</b>\n\n/gsearch nom\n/groups\n/gblock — joriy guruh\n/ungblock — joriy guruh\n/id — joriy chat ID",InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='games':
        lines=["🎮 <b>Faol o‘yinlar</b>",""]
        active=[g for g in games.values() if g.get('phase') not in {'ended','cancelled'}]
        if not active: lines.append("— Hozircha faol o‘yin yo‘q")
        else:
            for g in active: lines.append(f"• {html.escape(str(g.get('chat_id')))} — {g.get('mode','classic')} — {len(g.get('players',{}))} ta — {g.get('phase')}")
        return await safe_edit(q,"\n".join(lines),InlineKeyboardMarkup([[InlineKeyboardButton('🛑 Barchasini to‘xtatish',callback_data='admin:stopgames')],[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='stopgames':
        n=0
        for g in list(games.values()):
            if g.get('phase') not in {'ended','cancelled'}:
                cancel_jobs(g); g['phase']='cancelled'; g['ended']=True; n+=1
        persist_games(); admin_log('stop_all_games',n)
        return await safe_edit(q,f"🛑 {n} ta o‘yin to‘xtatildi.",InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='blocks':
        con=db(); bu=con.execute("SELECT user_id FROM admin_blocked_users ORDER BY created_at DESC LIMIT 50").fetchall(); bg=con.execute("SELECT chat_id,title FROM admin_blocked_groups ORDER BY created_at DESC LIMIT 50").fetchall(); con.close()
        text="🚫 <b>Bloklar</b>\n\n<b>Userlar:</b>\n"+('\n'.join(f'• {r[0]}' for r in bu) if bu else '—')+"\n\n<b>Guruhlar:</b>\n"+('\n'.join(f'• {html.escape(str(r[1] or r[0]))} ({r[0]})' for r in bg) if bg else '—')
        return await safe_edit(q,text,InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='active':
        con=db(); rows=con.execute("SELECT user_id,role FROM admin_forced_roles ORDER BY user_id").fetchall(); ar=con.execute("SELECT user_id,role FROM admin_active_roles WHERE is_active=1 ORDER BY user_id,created_at").fetchall(); con.close()
        text="🎭 <b>Aktiv rollar</b>\n\n<b>Admin majburiy rollari:</b>\n"+('\n'.join(f'• {r[0]} → {r[1]}' for r in rows) if rows else '—')+"\n\n<b>Sotib olingan:</b>\n"+('\n'.join(f'• {r[0]} → {r[1]}' for r in ar) if ar else '—')
        return await safe_edit(q,text,InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='money':
        return await safe_edit(q,"💰 <b>Valyuta / Inventar</b>\n\n/pul ID amount\n/olmos ID amount\n/coin ID amount\n/inventory ID\n/bust ID",InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='heroes':
        con=db(); rows=con.execute("SELECT user_id,name,level,ball,patron,shield FROM heroes ORDER BY level DESC LIMIT 100").fetchall(); con.close();
        text="🥷 <b>Geroylar</b>\n\n"+('\n'.join(f"• {r[0]} — {html.escape(str(r[1]))} — Lv.{r[2]} — {r[3]} ball" for r in rows) if rows else '—')
        return await safe_edit(q,text,InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='vips':
        con=db(); rows=con.execute("SELECT user_id FROM admin_vips ORDER BY created_at DESC").fetchall(); con.close(); text="🌟 <b>VIP userlar</b>\n\n"+('\n'.join(f'• {r[0]}' for r in rows) if rows else '—')+"\n\n/vip ID — qo‘shish\n/unvip ID — olib tashlash"; return await safe_edit(q,text,InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='logs':
        con=db(); rows=con.execute("SELECT action,target,created_at FROM admin_logs ORDER BY id DESC LIMIT 30").fetchall(); con.close(); text="📝 <b>Admin loglari</b>\n\n"+('\n'.join(f"• {datetime.fromtimestamp(r[2]).strftime('%d.%m %H:%M')} — {html.escape(str(r[0]))} {html.escape(str(r[1]))}" for r in rows) if rows else '—'); return await safe_edit(q,text,InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    if key=='broadcast':
        ctx.user_data['admin_state']={'kind':'broadcast'}
        return await safe_edit(q,"📢 Yuboriladigan xabarni oddiy matn qilib yuboring.\nBekor qilish: /cancel",InlineKeyboardMarkup([[InlineKeyboardButton('🔙 Orqaga',callback_data='admin:home')]]))
    return await cb_answer(q)


# ---------------- ADMIN COMMANDS ----------------
def _target_id(update):
    if getattr(update,'message',None) and update.message.reply_to_message and update.message.reply_to_message.from_user:
        return update.message.reply_to_message.from_user.id
    parts=(update.message.text or '').split() if getattr(update,'message',None) else []
    if len(parts)>1 and parts[1].lstrip('-').isdigit(): return int(parts[1])
    return None

async def cmd_aktiv(update,ctx):
    if not _admin_only(update) or not update.message: return
    uid=_target_id(update)
    raw=(update.message.text or '').split(maxsplit=1)
    role=_role_from_text(raw[1] if len(raw)>1 else '')
    if not uid or not role: return await update.message.reply_text("❌ Reply qiling va /aktiv <rol> yozing.\nMasalan: /aktiv Don")
    con=db(); con.execute("INSERT INTO admin_forced_roles(user_id,role,set_by,created_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET role=excluded.role,set_by=excluded.set_by,created_at=excluded.created_at",(uid,role,ADMIN_ID,time.time())); con.commit(); con.close(); admin_log('aktiv',f'{uid}:{role}')
    await update.message.reply_text(f"✅ {uid} uchun doimiy aktiv rol: {EMOJI.get(role,'🎭')} {role}")

async def cmd_unaktiv(update,ctx):
    if not _admin_only(update) or not update.message: return
    uid=_target_id(update)
    if not uid: return await update.message.reply_text("❌ User ID yoki reply kerak.")
    con=db(); cur=con.execute("DELETE FROM admin_forced_roles WHERE user_id=?",(uid,)); con.commit(); con.close(); admin_log('unaktiv',uid)
    await update.message.reply_text("✅ Aktiv rol olib tashlandi." if cur.rowcount else "ℹ️ Bu userda admin aktiv roli yo‘q.")

async def cmd_block(update,ctx):
    if not _admin_only(update) or not update.message: return
    uid=_target_id(update)
    if not uid: return await update.message.reply_text("❌ /block ID yoki user xabariga reply qiling.")
    con=db(); con.execute("INSERT OR REPLACE INTO admin_blocked_users(user_id,reason,created_at) VALUES(?,?,?)",(uid,'admin',time.time())); con.commit(); con.close(); admin_log('block_user',uid)
    # Remove the blocked user from current lobbies/games.
    for g in list(games.values()):
        p=g.get('players',{}).get(uid)
        if p:
            if g.get('phase')=='lobby': g['players'].pop(uid,None)
            else: p['alive']=False
    persist_games(); await update.message.reply_text("🚫 Foydalanuvchi bloklandi.")

async def cmd_unblock(update,ctx):
    if not _admin_only(update) or not update.message: return
    uid=_target_id(update)
    if not uid: return await update.message.reply_text("❌ /unblock ID yoki reply.")
    con=db(); cur=con.execute("DELETE FROM admin_blocked_users WHERE user_id=?",(uid,)); con.commit(); con.close(); admin_log('unblock_user',uid); await update.message.reply_text("🔓 Blok olib tashlandi." if cur.rowcount else "ℹ️ User bloklanmagan.")

async def cmd_gblock(update,ctx):
    if not _admin_only(update) or update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    cid=update.effective_chat.id; title=update.effective_chat.title or ''
    con=db(); con.execute("INSERT OR REPLACE INTO admin_blocked_groups(chat_id,title,created_at) VALUES(?,?,?)",(cid,title,time.time())); con.commit(); con.close(); admin_log('block_group',cid)
    g=games.get(cid)
    if g: cancel_jobs(g); g['phase']='cancelled'; g['ended']=True; persist_games()
    await update.message.reply_text("🚫 Bu guruh bloklandi. Bot bu guruhda o‘yin buyruqlariga javob bermaydi.")

async def cmd_gunblock(update,ctx):
    if not _admin_only(update) or update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    cid=update.effective_chat.id; con=db(); cur=con.execute("DELETE FROM admin_blocked_groups WHERE chat_id=?",(cid,)); con.commit(); con.close(); admin_log('unblock_group',cid); await update.message.reply_text("🔓 Guruh blokdan chiqarildi." if cur.rowcount else "ℹ️ Guruh bloklanmagan.")

async def cmd_checkuser(update,ctx):
    if not _admin_only(update): return
    uid=_target_id(update) or ADMIN_ID; r=get_user(uid)
    if not r: return await update.message.reply_text("❌ Foydalanuvchi topilmadi.")
    vip=bool(db().execute("SELECT 1 FROM admin_vips WHERE user_id=?",(uid,)).fetchone()) if False else False
    con=db(); blocked=bool(con.execute("SELECT 1 FROM admin_blocked_users WHERE user_id=?",(uid,)).fetchone()); forced=con.execute("SELECT role FROM admin_forced_roles WHERE user_id=?",(uid,)).fetchone(); ar=con.execute("SELECT role FROM admin_active_roles WHERE user_id=? AND is_active=1",(uid,)).fetchall(); con.close()
    await update.message.reply_text(f"👤 <b>{html.escape(str(r['first_name'] or 'Nomsiz'))}</b>\nID: <code>{uid}</code>\n💷 {r['money']}\n💎 {r['diamonds']}\n🪙 {r['coins']}\n🎮 {r['games']}\n🏆 {r['wins']}\n🚫 Blok: {'Ha' if blocked else 'Yo‘q'}\n🎭 /aktiv: {forced[0] if forced else 'Yo‘q'}\n🃏 Faol: {', '.join(x[0] for x in ar) if ar else 'Yo‘q'}")

async def cmd_inventory(update,ctx):
    if not _admin_only(update): return
    uid=_target_id(update) or (int(ctx.args[0]) if ctx.args and ctx.args[0].isdigit() else None)
    if not uid: return await update.message.reply_text("/inventory ID")
    d=inv(uid); await update.message.reply_text("🎒 <b>Inventory</b>\n\n"+"\n".join(f"• {k}: {v}" for k,v in d.items()))

async def _give_currency(update, field, symbol):
    if not _admin_only(update): return
    parts=(update.message.text or '').split(); uid=_target_id(update)
    if not uid and len(parts)>=3 and parts[1].lstrip('-').isdigit(): uid=int(parts[1])
    if uid and len(parts)>=2 and parts[-1].lstrip('-').isdigit():
        amount=int(parts[-1])
    else:
        return await update.message.reply_text("Foydalanish: /pul ID amount yoki user xabariga reply qilib /pul amount")
    con=db(); con.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)",(uid,)); con.execute(f"UPDATE users SET {field}={field}+? WHERE user_id=?",(amount,uid)); con.commit(); con.close(); admin_log('give',f'{uid}:{field}:{amount}'); await update.message.reply_text(f"✅ {amount}{symbol} berildi.")

async def cmd_pul(update,ctx): await _give_currency(update,'money','💷')
async def cmd_olmos(update,ctx): await _give_currency(update,'diamonds','💎')
async def cmd_coin(update,ctx): await _give_currency(update,'coins','🪙')

async def cmd_bust(update,ctx):
    if not _admin_only(update): return
    uid=_target_id(update)
    if not uid: return await update.message.reply_text("/bust ID yoki reply")
    con=db(); con.execute("UPDATE users SET money=0,diamonds=0,coins=0 WHERE user_id=?",(uid,)); con.commit(); con.close(); admin_log('bust',uid); await update.message.reply_text("💥 User hisoblari 0 qilindi.")

async def cmd_vip(update,ctx,remove=False):
    if not _admin_only(update): return
    uid=_target_id(update) or (int(ctx.args[0]) if ctx.args and ctx.args[0].isdigit() else None)
    if not uid: return await update.message.reply_text("/vip ID")
    con=db()
    if remove: cur=con.execute("DELETE FROM admin_vips WHERE user_id=?",(uid,))
    else: cur=con.execute("INSERT OR IGNORE INTO admin_vips(user_id,created_at) VALUES(?,?)",(uid,time.time()))
    con.commit(); con.close(); admin_log('unvip' if remove else 'vip',uid); await update.message.reply_text("🔓 VIP olib tashlandi." if remove else "🌟 VIP berildi.")

async def cmd_unvip(update,ctx): await cmd_vip(update,ctx,True)

async def cmd_blocks(update,ctx):
    if not _admin_only(update): return
    con=db(); u=con.execute("SELECT user_id FROM admin_blocked_users ORDER BY created_at DESC").fetchall(); g=con.execute("SELECT chat_id,title FROM admin_blocked_groups ORDER BY created_at DESC").fetchall(); con.close(); await update.message.reply_text("🚫 Userlar:\n"+('\n'.join(str(x[0]) for x in u) if u else '—')+"\n\n🚫 Guruhlar:\n"+('\n'.join(f'{x[1]} ({x[0]})' for x in g) if g else '—'))

async def cmd_id(update,ctx):
    if _admin_only(update): await update.message.reply_text(f"🆔 Chat ID: <code>{update.effective_chat.id}</code>\n👤 User ID: <code>{update.effective_user.id}</code>")

async def cmd_gsearch(update,ctx):
    if not _admin_only(update): return
    q=' '.join(ctx.args or []).lower().strip()
    if not q: return await update.message.reply_text("/gsearch guruh nomi")
    con=db(); rows=con.execute("SELECT chat_id,title,username FROM admin_known_groups WHERE lower(title) LIKE ? ORDER BY title LIMIT 30",('%'+q+'%',)).fetchall(); con.close(); await update.message.reply_text("🔎 Topildi:\n\n"+('\n'.join(f"• {r[1]} — {r[0]}" for r in rows) if rows else '—'))

async def cmd_groups(update,ctx):
    if not _admin_only(update): return
    con=db(); rows=con.execute("SELECT chat_id,title,username FROM admin_known_groups ORDER BY title LIMIT 100").fetchall(); con.close(); await update.message.reply_text("🏠 <b>Guruhlar</b>\n\n"+('\n'.join(f"• {html.escape(str(r[1] or 'Nomsiz'))} — <code>{r[0]}</code>" for r in rows) if rows else '—'))

async def cmd_active_games(update,ctx):
    if not _admin_only(update): return
    rows=[g for g in games.values() if g.get('phase') not in {'ended','cancelled'}]
    await update.message.reply_text("🎮 <b>Faol o‘yinlar</b>\n\n"+('\n'.join(f"• {g['chat_id']} — {g.get('mode')} — {len(g.get('players',{}))} — {g.get('phase')}" for g in rows) if rows else '—'))

async def cmd_checkgaming(update,ctx):
    if not _admin_only(update): return
    uid=int(ctx.args[0]) if ctx.args and ctx.args[0].isdigit() else _target_id(update)
    if not uid: return await update.message.reply_text('/checkgaming ID')
    rows=[]
    for g in games.values():
        if uid in g.get('players',{}): rows.append(f"• {g['chat_id']} — {g.get('mode')} — {g.get('phase')}")
    await update.message.reply_text("🎮 User o‘ynayotgan guruhlar:\n\n"+('\n'.join(rows) if rows else '—'))

async def cmd_stopgames(update,ctx):
    if not _admin_only(update): return
    n=0
    for g in list(games.values()):
        if g.get('phase') not in {'ended','cancelled'}: cancel_jobs(g); g['phase']='cancelled'; g['ended']=True; n+=1
    persist_games(); admin_log('stop_all_games',n); await update.message.reply_text(f'🛑 {n} ta o‘yin to‘xtatildi.')

async def cmd_stats(update,ctx):
    if not _admin_only(update): return
    con=db(); row=con.execute("SELECT COUNT(*),COALESCE(SUM(games),0),COALESCE(SUM(wins),0),COALESCE(SUM(money),0),COALESCE(SUM(diamonds),0) FROM users").fetchone(); con.close(); await update.message.reply_text(f"📊 Userlar: {row[0]}\n🎮 O‘yinlar: {row[1]}\n🏆 G‘alabalar: {row[2]}\n💷 Pullar: {row[3]}\n💎 Olmos: {row[4]}")

async def cmd_top(update,ctx):
    if not _admin_only(update): return
    con=db(); rows=con.execute("SELECT first_name,user_id,wins,games,money,diamonds FROM users ORDER BY wins DESC,games DESC LIMIT 100").fetchall(); con.close(); await update.message.reply_text("🏆 <b>TOP userlar</b>\n\n"+('\n'.join(f"{i}. {html.escape(str(r[0] or 'Nomsiz'))} — {r[2]}🏆 / {r[3]}🎮 — {r[4]}💷 / {r[5]}💎" for i,r in enumerate(rows,1)) if rows else '—'))

async def cmd_heroes(update,ctx):
    if not _admin_only(update): return
    con=db(); rows=con.execute("SELECT user_id,name,level,ball FROM heroes ORDER BY level DESC LIMIT 100").fetchall(); con.close(); await update.message.reply_text("🥷 <b>Geroylar</b>\n\n"+('\n'.join(f"• {r[0]} — {html.escape(str(r[1]))} — Lv.{r[2]} — {r[3]} ball" for r in rows) if rows else '—'))

async def cmd_rgm(update,ctx):
    if not _admin_only(update): return
    uid=int(ctx.args[0]) if ctx.args and ctx.args[0].isdigit() else _target_id(update)
    if not uid: return await update.message.reply_text('/rgm ID')
    con=db(); cur=con.execute("DELETE FROM hero_market WHERE seller_id=?",(uid,)); con.commit(); con.close(); await update.message.reply_text('✅ Geroy Market e’loni olib tashlandi.' if cur.rowcount else '❌ E’lon topilmadi.')

async def cmd_broadcast(update,ctx):
    if not _admin_only(update): return
    text=(update.message.text or '').split(maxsplit=1)
    if len(text)<2:
        ctx.user_data['admin_state']={'kind':'broadcast'}; return await update.message.reply_text('📢 Xabar matnini yuboring. /cancel — bekor qilish')
    await do_broadcast(ctx.bot,text[1],update.message)

async def do_broadcast(bot,text,reply=None):
    con=db(); ids=[r[0] for r in con.execute('SELECT user_id FROM users').fetchall()]; con.close(); ok=fail=0
    for uid in ids:
        if _blocked_user(uid): continue
        try: await bot.send_message(uid,text); ok+=1
        except Exception: fail+=1
        await asyncio.sleep(0.05)
    admin_log('broadcast',f'ok={ok},fail={fail}')
    if reply: await reply.reply_text(f'📢 Broadcast tugadi.\n✅ {ok}\n❌ {fail}')

async def admin_text_handler(update,ctx):
    if not _admin_only(update) or not update.message: return
    state=ctx.user_data.get('admin_state')
    if not state: return
    text=(update.message.text or '').strip()
    if text=='/cancel': ctx.user_data.pop('admin_state',None); return await update.message.reply_text('❌ Bekor qilindi.')
    if state.get('kind')=='broadcast': ctx.user_data.pop('admin_state',None); return await do_broadcast(ctx.bot,text,update.message)

async def cmd_zapravka1(update,ctx):
    if not _admin_only(update): return
    con=db(); con.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)",(ADMIN_ID,)); con.execute("UPDATE users SET diamonds=diamonds+100 WHERE user_id=?",(ADMIN_ID,)); con.commit(); con.close(); await update.message.reply_text("✅ Sizga 100 💎 berildi!")
async def cmd_zapravka7(update,ctx):
    if not _admin_only(update): return
    con=db(); con.execute("INSERT OR IGNORE INTO users(user_id) VALUES(?)",(ADMIN_ID,)); con.execute("UPDATE users SET money=money+10000 WHERE user_id=?",(ADMIN_ID,)); con.commit(); con.close(); await update.message.reply_text("✅ Sizga 10 000 💷 berildi!")

# ---------------- PROFILE WITH ACTIVE ROLES ----------------
_ORIGINAL_PROFILE_TEXT = profile_text

def profile_text(uid):
    base=_ORIGINAL_PROFILE_TEXT(uid)
    rows=active_roles_for(uid)
    # Replace the old numeric active-role line with actual names.
    lines=base.splitlines(); out=[]
    for line in lines:
        if line.strip().startswith('🃏'):
            continue
        out.append(line)
    if rows:
        out.append('🃏 <b>Faol rollar:</b>')
        out.extend(f"{EMOJI.get(r[1],'🎭')} {html.escape(r[1])}" for r in rows)
    else: out.append('🃏 <b>Faol rollar:</b> 0')
    return '\n'.join(out)

# ---------------- STARTUP HOOK ----------------
_admin_db_init()

# Wrap the existing market callback so the Active Role button opens the real role list.
_EPIC_BASE_CB_BUY = cb_buy
async def cb_buy(update,ctx):
    q=update.callback_query
    item=q.data.split(":",1)[1] if q.data else ''
    if item=='active':
        if q.message.chat.type!=ChatType.PRIVATE:
            return await cb_answer(q,"Faqat shaxsiy chatda.",True)
        await cb_answer(q)
        await safe_edit(q,active_role_text(q.from_user.id),active_role_market_markup())
        return
    return await _EPIC_BASE_CB_BUY(update,ctx)
