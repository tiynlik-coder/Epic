async def resolve_night(ctx):
    d=ctx.job.data; chat_id=next((cid for cid,g in games.items() if g["id"]==d["gid"]),None)
    if chat_id is None:return
    g=games[chat_id]
    if not valid_job(g,d) or g["phase"]!="night":return
    # Kezuvchi blocks target's action; first resolve blocks before other actions.
    blocks={}
    for p in list(g["players"].values()):
        if ability_role(p)=="Kezuvchi" and p["action"] and p["action"].get("target"):
            t=getp(g,p["action"]["target"])
            if t: blocks[t["id"]]=True; t["blocked"]=True
            p["visits"].append(t["id"] if t else None)
    # Veyron's swap applies on the NEXT night only. It never changes roles/factions.
    g.setdefault("next_ability_swaps", {})
    g["next_ability_swaps"]={}
    g["veyron_notice"]=[]
    for p in list(g["players"].values()):
        a=p.get("action") or {}
        if ability_role(p)=="Veyron" and a.get("type")=="veyron" and a.get("second") and not p.get("blocked"):
            x=getp(g,a["first"]); y=getp(g,a["second"])
            if not x or not y: continue
            # Veyron's already-selected swap resolves even if Veyron dies later.
            # If exactly one selected player survives, that survivor receives the dead player's ability.
            if x.get("alive") and y.get("alive"):
                g["next_ability_swaps"][str(x["id"])] = y["role"]
                g["next_ability_swaps"][str(y["id"])] = x["role"]
            elif x.get("alive") and not y.get("alive"):
                if y.get("role") != "Don":
                    g["next_ability_swaps"][str(x["id"])] = y.get("role")
                else:
                    continue
            elif y.get("alive") and not x.get("alive"):
                if x.get("role") != "Don":
                    g["next_ability_swaps"][str(y["id"])] = x.get("role")
                else:
                    continue
            else:
                continue
            g["veyron_notice"].append({"x":x["id"],"y":y["id"]})
    deaths=[]; attacks=[]
    def effective_role(p): return ability_role(p)

    # Pre-compute night effects that must not depend on actor iteration order.
    for actor in list(g["players"].values()):
        a=actor.get("action") or {}
        if actor.get("blocked") or not a.get("target"): continue
        target=getp(g,a.get("target"))
        if not target: continue
        er=effective_role(actor)
        if er=="Advokat":
            target["advokat_result"]=True
        if er=="Manipulyator":
            actor["manipulations"]=actor.get("manipulations",0)+1
            if actor["manipulations"]>=5:
                actor["alive"]=False; actor["hp"]=0
    # Manipulyator redirects the selected player's already-selected action to a second target.
    # Kezuvchi and Snayper are immune to manipulation. The fifth control still executes, then Manipulyator dies.
    for manip in list(g["players"].values()):
        if ability_role(manip)!="Manipulyator" or manip.get("blocked"): continue
        ma=manip.get("action") or {}
        controlled=getp(g,ma.get("controlled")) if ma.get("controlled") else None
        redirected=getp(g,ma.get("redirect_target")) if ma.get("redirect_target") else None
        if not controlled or not redirected or controlled.get("role") in {"Kezuvchi","Snayper"}: continue
        ca=controlled.get("action") or {}
        if ca.get("target") is not None:
            ca["original_target"]=ca.get("target")
            ca["target"]=redirected["id"]
        elif ca.get("type")=="veyron":
            # Veyron's two-person selection is not redirectable.
            pass
        elif ca.get("type")=="professor" and ca.get("choice")=="death":
            ca["target"]=redirected["id"]
        controlled["action"]=ca
        manip["manipulations"]=manip.get("manipulations",0)+1
        if manip["manipulations"]>=5:
            manip["alive"]=False; manip["hp"]=0
            await ctx.bot.send_message(g["chat_id"],"🧠 Manipulyator boshqaruv jarayonida halok bo‘ldi.")

    # Register visits for Daydi: owner is not a visitor.
    for actor in list(living(g)):
        a=actor.get("action") or {}; typ=a.get("type"); target=getp(g,a.get("target")) if a.get("target") else None
        if not target or not actor["alive"]: continue
        if actor["blocked"]: continue
        er=effective_role(actor)
        if er=="Ruhoniy" and typ=="resurrect":
            if not target["alive"] and actor.get("resurrections",0)<3:
                target["alive"]=True; target["hp"]=target["max_hp"]; actor["resurrections"]=actor.get("resurrections",0)+1
                await send_private(ctx.bot,target["id"],"✝️ Siz Ruhoniy tomonidan qaytarildingiz!")
                await ctx.bot.send_message(g["chat_id"],f"✝️ {visible_name(g,target,True)} o‘yinga qaytdi.")
            continue

        if target["alive"]: target["visits"].append(actor["id"])
        if g.get("mode")=="zombie" and er=="Zombi":
            # Zombie conversion is resolved at dawn; protection/heal does not block it.
            if target["role"]!="Zombi":
                g.setdefault("mode_state",{}).setdefault("zombie_pending",[]).append({"target":target["id"],"selected_at":a.get("selected_at",time.time()),"zombie":actor["id"]})
            continue
        # ordinary / special actions
        if er in ORDINARY_KILLERS: attacks.append((actor,target,er))
        elif er=="Snayper": attacks.append((actor,target,"Snayper"))
        elif er=="Minior": attacks.append((actor,target,"Minior"))
        elif er=="Professor" and a.get("type")=="professor" and a.get("choice")=="death": attacks.append((actor,target,"Professor"))
        elif er=="Komissar Katani" and typ=="check":
            result="Tinch aholi" if target["role"] in TOWN else "Mafia/Yakka"
            await send_private(ctx.bot,actor["id"],f"🕵🏻‍♂️ Tekshiruv natijasi: {mention(target)} — {result}.")
        elif er=="Komissar Katani" and typ=="kill": attacks.append((actor,target,"Komissar Katani"))
        elif er=="Koldun":
            if target["role"] in TOWN:
                target["hanging_protected"]=True
            else: attacks.append((actor,target,"Koldun"))
        elif er in {"Shifokor","Tabib"}:
            target["hp"] += 50
            target["temp_hp_bonus"] = target.get("temp_hp_bonus",0) + 50
        elif er=="Undiruvchi":
            # Fictional in-game money action.
            con=db(); amount=random.randint(1,200); con.execute("UPDATE users SET money=MAX(0,money-?) WHERE user_id=?",(amount,target["id"])); con.commit(); con.close()
        elif er=="Zodagon":
            if target["role"] in TOWN: await ctx.bot.send_message(g["chat_id"],"👑 Zodagon tanlovida adashdi.")
            else:
                amount=random.randint(1,200); con=db(); con.execute("UPDATE users SET money=money+? WHERE user_id=?",(amount,target["id"])); con.commit(); con.close(); await ctx.bot.send_message(g["chat_id"],"👑 Zodagon kimnidir xursand qilmoqchi.")
        elif er=="Folbin":
            result="Tinch aholi" if target["role"] in TOWN else "Mafia" if target["role"] in MAFIA else "Yakka"
            if target.get("advokat_result"): result="Tinch aholi"
            await send_private(ctx.bot,actor["id"],f"🧿 Tonggi natija: {mention(target)} — {result} taraf.")
            for cp in living(g):
                if ability_role(cp)=="Komissar Katani":
                    await send_private(ctx.bot,cp["id"],"🧿 Sizga Folbindan yangi xabar bor.",InlineKeyboardMarkup([[InlineKeyboardButton("📖 Xabarni o‘qish",callback_data=f"read_f:{g['id']}:{target['id']}:{result}" )],[InlineKeyboardButton("❌ Bekor qilish",callback_data=f"cancel_f:{g['id']}")]]))
        elif er=="Ayg‘oqchi":
            # Ayg‘oqchi receives a private role read; Fake Document masks it.
            result_role="Tinch axoli" if target.get("fake_document") else target["role"]
            await send_private(ctx.bot,actor["id"],f"🕵️ Siz {mention(target)}ning {role_label(result_role)} ekanini aniqladingiz.")
        elif er=="Advokat":
            pass
        elif er=="Qorbobo":
            gifts=["protection","hanging_protection","supper_shield","mask","rifle","active_role"]
            gift=random.choice(gifts)
            if target.get("alive"):
                d=inv(target["id"]); d[gift]=int(d.get(gift,0))+1; set_inv(target["id"],d)
                await send_private(ctx.bot,target["id"],f"🎅 Sizga tasodifiy sovg‘a keldi: {gift} 🎁")
        elif er=="Sotqin":
            if target["role"] in MAFIA or target["role"] in HARMFUL_ACTION_ROLES:
                if not target.get("fake_document"):
                    await ctx.bot.send_message(g["chat_id"],f"🦎 Sotqin [ {mention(target)} ]ning yovuz/harmli ekanini aniqladi. {role_label(target['role'])}",parse_mode=ParseMode.HTML)
            else: await ctx.bot.send_message(g["chat_id"],"🦎 Sotqinning izlanishlari bekor ketdi.")
        elif er=="Daydi":
            visitors=[getp(g,x) for x in target["visits"] if getp(g,x)]
            if not visitors:
                text=f"🏠 Xavfsiz yotibdi. Bugun siz {mention(target)}ning derazasidan kuzatdingiz va hech qanday shubhali harakat sezmadingiz."
            else:
                visible_visitors=[]
                for v in visitors:
                    if v["id"]==target["id"]: continue
                    if v.get("role")=="Snayper": continue
                    rr="🎭 Noma’lum" if v.get("mask") else role_label(v["role"])
                    visible_visitors.append(rr)
                text="🌙 Siz "+mention(target)+"ning derazasidan kuzatdingiz.\n\nKelganlar:\n"+"\n".join(visible_visitors)
            await send_private(ctx.bot,actor["id"],text)
    # Hero actions resolve at dawn alongside the game actions. They are independent of role/faction.
    for actor in list(g["players"].values()):
        ha=actor.get("hero_action") or {}
        if actor.get("blocked"):
            actor["hero_action"]=None
            continue
        if not ha: continue
        h=hero_row(actor["id"])
        if not h: continue
        if ha.get("type")=="attack" and ha.get("target") and h["patron"]>0:
            target=getp(g,ha["target"])
            if target and target.get("alive"):
                if target.get("hero_protection"):
                    target["hero_protection"]=False; consume_inventory(target,"hero_protection")
                    await send_private(ctx.bot,target["id"],"🔰 Geroydan himoya sizni Geroy hujumidan saqlab qoldi.")
                else:
                    dmg=random.randint(*hero_damage_range(h["level"]))
                    target_hero=hero_row(target["id"])
                    if target_hero and target_hero["shield"]>0:
                        absorbed=min(target_hero["shield"],dmg); dmg-=absorbed
                        con=db(); con.execute("UPDATE heroes SET shield=shield-? WHERE user_id=?",(absorbed,target["id"])); con.commit(); con.close()
                    con=db(); con.execute("UPDATE heroes SET patron=patron-1 WHERE user_id=?",(actor["id"],)); con.commit(); con.close()
                    target["hp"]-=dmg
                    if target["hp"]<=0:
                        kill_player(target,"hero")
                        actor_h=hero_row(actor["id"]); newball=actor_h["ball"]+actor_h["level"]+1
                        con=db(); con.execute("UPDATE heroes SET ball=?,level=? WHERE user_id=?",(newball,hero_level(newball),actor["id"])); con.commit(); con.close()
                        await ctx.bot.send_message(g["chat_id"],f"🥷 {visible_name(g,actor,True)}ning Geroyi {visible_name(g,target,True)}ni mag‘lub etdi.")
                    else:
                        actor_h=hero_row(actor["id"]); newball=actor_h["ball"]+actor_h["level"]
                        con=db(); con.execute("UPDATE heroes SET ball=?,level=? WHERE user_id=?",(newball,hero_level(newball),actor["id"])); con.commit(); con.close()
                        await ctx.bot.send_message(g["chat_id"],f"🥷 Geroy hujumi {visible_name(g,target,True)}ga {dmg}% zarar yetkazdi. Qolgan HP: {max(0,target['hp'])}%.")
        elif ha.get("type")=="shield":
            mx=hero_max_shield(h["level"])
            con=db(); con.execute("UPDATE heroes SET shield=? WHERE user_id=?",(mx,actor["id"])); con.commit(); con.close()
            await send_private(ctx.bot,actor["id"],f"🛡 Geroy himoyasi yangilandi: {mx}.")
        actor["hero_action"]=None

    # All night actions resolve together, ordered only by immutable selection time.
    attacks.sort(key=lambda item: (item[0].get("action") or {}).get("selected_at", float("inf")))
    # Manipulator redirection is applied before attacks in a full implementation; for safety, action targets are redirected here.
    for actor,target,kr in attacks:
        if not actor["alive"] or not target["alive"]: continue
        if kr=="Snayper" and target["role"]=="Afsungar": continue
        if target["role"]=="Afsungar":
            # Afsungar gets a decision, attacker waits.
            target["afsungar_decisions"].setdefault(actor["id"],None)
            await ctx.bot.send_message(g["chat_id"],f"⚠️ {role_label(kr)} Afsungarni o‘ldirishga urindi! 🧙‍♀️ Afsungar uni kechiradimi yoki o‘ldiradimi? Buni tongda bilamiz.")
            await send_private(ctx.bot,target["id"],f"⚠️ {mention(actor)} ({role_label(kr)}) sizni o‘ldirishga urindi!\nEndi uning taqdirini siz hal qilasiz.",InlineKeyboardMarkup([[InlineKeyboardButton("🕊️ Kechirish",callback_data=f"af:{g['id']}:{target['id']}:{actor['id']}:forgive")],[InlineKeyboardButton("☠️ O‘ldirish",callback_data=f"af:{g['id']}:{target['id']}:{actor['id']}:kill")]]))
            continue
        if target["supper"] or target["protected"]:
            blocked=apply_protection(target,kr)
            if blocked:
                await send_private(ctx.bot,target["id"],f"🛡 Sizning uyingizga {role_label(kr)} hujum qildi, ammo himoya sizni saqlab qoldi.")
                continue
        if kr=="Professor" and target["role"]=="Kamikaze":
            kill_player(target); deaths.append((target,actor,kr)); continue
        if kr=="Snayper":
            kill_player(target); deaths.append((target,actor,kr)); continue
        if kr=="Minior":
            kill_player(target); deaths.append((target,actor,kr)); continue
        # HP-based ordinary damage; Tabib +50 is already applied.
        target["hp"]-=100
        if target["hp"]<=0:
            kill_player(target); deaths.append((target,actor,kr))
    # Afsungar decisions are made after the attack is reported, then resolved by a short
    # decision phase before dawn. Do not resolve immediately: the player must be able to click.
    pending_afsungar = [af for af in g["players"].values() if af.get("afsungar_decisions")]

    # La’natchi: damage only the exact selected actor when that actor really caused a kill.
    for lp in living(g):
        if lp.get("role")!="La’natchi": continue
        action=lp.get("action") or {}
        marked=action.get("target")
        if not marked: continue
        caused=[(victim,killer,kr) for victim,killer,kr in deaths if killer and killer.get("id")==marked]
        if not caused: continue
        killer=getp(g,marked)
        if not killer or killer.get("role") in {"Minior","Afsungar"}: continue
        damage=25 if any(kr in {"Snayper","Professor"} for _,_,kr in caused) else 50
        killer["hp"]-=damage
        if killer["hp"]<=0: kill_player(killer,"la'natchi")
    # Bounty payout: only the killer whose action actually caused the death qualifies.
    # Bounty winner is the killer whose attack actually caused the death.
    # Attacks are resolved by the immutable night selection timestamp.
    for victim,killer,kr in list(deaths):
        if not killer: continue
        for bounty in list(g.get("bounties", [])):
            if bounty["target"] != victim["id"]: continue
            con=db(); con.execute("UPDATE users SET money=money+? WHERE user_id=?",(bounty["amount"],killer["id"])); con.commit(); con.close()
            amount=bounty["amount"]
            await ctx.bot.send_message(g["chat_id"], f"🎯 {visible_name(g,victim,True)} uchun {amount}💷 bounty {visible_name(g,killer,True)}ga berildi!")
            g["bounties"].remove(bounty)
    persist_games()

    # Kamikaze retaliation: every actual killer of Kamikaze is taken out, except Professor.
    for victim,killer,kr in list(deaths):
        if victim.get("role")!="Kamikaze" or victim.get("kamikaze_used"): continue
        killers=[]
        for a,t,krole in attacks:
            if t.get("id")==victim.get("id") and krole!="Professor" and a.get("alive"):
                if a not in killers: killers.append(a)
        if killers:
            victim["kamikaze_used"]=True
            for k in killers:
                if k.get("alive"):
                    kill_player(k,"kamikaze")
                    deaths.append((k,victim,"Kamikaze"))
            await ctx.bot.send_message(g["chat_id"],f"💥 Kamikaze {mention(victim)} halok bo‘ldi va hujumchilarni ham o‘zi bilan olib ketdi.")
    # Shifokor report: every attacked target gets a dawn report; the Doctor gets a result too.
    for victim in g["players"].values():
        attackers=[(a,k) for a,t,k in attacks if t["id"]==victim["id"]]
        if not attackers: continue
        victim["last_attackers"]=[k for _,k in attackers]
        roles_text=", ".join(role_label(k) for _,k in attackers)
        await send_private(ctx.bot,victim["id"],f"Sizning uyingizga tunda {roles_text} keldi.")
        for doc in [p for p in g["players"].values() if ability_role(p)=="Shifokor"]:
            if any(k.get("id")==doc.get("id") for _,k in attackers): continue
            await send_private(ctx.bot,doc["id"],f"🩺 Sizning davolashingiz natijasi: {visible_name(g,victim,True)} — {'saqlandi' if victim.get('alive') else 'saqlanmadi'}.")
    # Daydi death witness at dawn: only if the visited owner died; owner is not a visitor.
    for p in list(g["players"].values()):
        if ability_role(p)=="Daydi" and p["action"] and p["action"].get("target"):
            target=getp(g,p["action"]["target"])
            if target and not target["alive"]:
                killers=[(a,k) for a,t,k in attacks if t["id"]==target["id"]]
                if killers:
                    k=killers[0][1]
                    await send_private(ctx.bot,p["id"],f"👁 Siz qotillik guvohi bo‘ldingiz. Murdaning ustida {role_label(k)} {mention(killers[0][0])} turardi.")
    g["night_deaths"]=[{"victim":v["id"],"killer":k["id"] if k else None,"role":kr} for v,k,kr in deaths]
    if pending_afsungar:
        g["phase"]="afsungar"; g["phase_id"]+=1
        persist_games()
        await schedule_afsungar_decision(ctx.application,g)
        return
    # End temp Veyron abilities after this night; actual swap is for NEXT night.
    g["phase"]="day"; g["phase_id"]+=1
    await start_day(ctx.application,g)

async def start_day(app,g):
    if g["ended"]: return
    cancel_jobs(g)
    # Serjant promotion happens before terminal-win evaluation.
    if not any(p.get("alive") and p.get("role")=="Komissar Katani" for p in g["players"].values()):
        for p in g["players"].values():
            if p.get("alive") and p.get("role")=="Serjant":
                p["role"]="Komissar Katani"; await send_private(app.bot,p["id"],"👮🏻‍♂️ Komissar Katani o‘ldi. Siz endi Komissar Katanisiz.")
                await app.bot.send_message(g["chat_id"],"👮🏻‍♂️ Serjant Komissar Kataniga aylandi."); break
    if game_over(g): return await end_game(app,g)
    nd=g.get("night_deaths",[])
    if nd:
        lines=["☠️ <b>Tunda o‘ldirilganlar:</b>"]
        for item in nd:
            vp=getp(g,item["victim"])
            if vp: lines.append(f"• {visible_mention(g,vp,True)} — {role_label(vp["role"])}")
        await app.bot.send_message(g["chat_id"],"\n".join(lines),parse_mode=ParseMode.HTML)
    # Keep the active game in memory through discussion/voting/night.
    # It is removed only by end_game(), so callbacks and timers remain valid.
    persist_games()
    a,b,c=role_lists(g)
    await app.bot.send_message(g["chat_id"],f"☀️ <b>TONG O‘TDI</b>\n\n{a}\n\n{b}\n\n{c}\n\nJami tirik o'yinchilar: {len(living(g))}\n\nEndi kecha tunda bo'lgan voqealarni muhokama qilamiz.",parse_mode=ParseMode.HTML)
    # Temporary +50 HP from Shifokor/Tabib expires at dawn.
    for p in g["players"].values():
        # The bonus is temporary capacity, not damage: any remaining HP stays,
        # but the temporary ceiling disappears at dawn.
        p["temp_hp_bonus"]=0
        p["max_hp"]=p.get("base_hp",150 if p.get("role")=="Tabib" else 100)
        if p["alive"]: p["hp"]=min(p["hp"],p["max_hp"])
    g["phase"]="discussion"; g["phase_id"]+=1
    persist_games()
    schedule_phase(app,g,DISCUSSION_TIME,start_voting,"discussion")

async def schedule_afsungar_decision(app,g):
    # Give Afsungar a short real callback window at the end of night.
    schedule_phase(app,g,10,resolve_afsungar,"afsungar")

async def resolve_afsungar(ctx):
    d=ctx.job.data; g=find_game(d.get("gid"))
    if not g or not valid_job(g,d) or g.get("phase")!="afsungar": return
    for af in g["players"].values():
        if af.get("role")!="Afsungar": continue
        for attacker_id, decision in list(af.get("afsungar_decisions",{}).items()):
            attacker=getp(g,int(attacker_id))
            if not attacker: continue
            if decision=="kill" and attacker.get("alive"):
                kill_player(attacker,"afsungar")
                await ctx.bot.send_message(g["chat_id"],f"🧙‍♀️ Afsungar {mention(af)} {role_label(attacker['role'])}ni kechira olmadi va o‘ldirishga qaror qildi.")
                await send_private(ctx.bot,attacker["id"],"🧙‍♀️ Afsungar sizni o‘ldirishga qaror qildi.")
            elif decision=="forgive":
                await ctx.bot.send_message(g["chat_id"],f"🕊️ Afsungar {mention(af)} {role_label(attacker['role'])}ni kechirishga qaror qildi.")
                await send_private(ctx.bot,attacker["id"],"🕊️ 🧙‍♀️ Afsungar sizni kechirishga qaror qildi.")
    for p in g["players"].values(): p["afsungar_decisions"]={}
    g["phase"]="day"; g["phase_id"]+=1
    persist_games()
    await start_day(ctx.application,g)

# ---------------- VOTING ----------------
async def start_voting(ctx):
    d=ctx.job.data
    g=find_game(d.get("gid"))
    if not g or not valid_job(g,d) or g.get("phase")!="discussion": return
    g["phase"]="voting"; g["phase_id"]+=1; g["votes"]={}; cancel_jobs(g); persist_games()
    rows=[[InlineKeyboardButton(visible_name(g,p)[:32],callback_data=f"vote:{g['id']}:{p['id']}")] for p in living(g)]
    rows.append([InlineKeyboardButton("⏭ Ovoz bermaslik",callback_data=f"skip:{g['id']}")])
    await ctx.bot.send_message(g["chat_id"],"🗳 <b>Ovoz berish boshlandi.</b>",reply_markup=InlineKeyboardMarkup(rows),parse_mode=ParseMode.HTML)
    schedule_phase(ctx.application,g,VOTING_TIME,resolve_vote,"vote")

async def cb_vote(update,ctx):
    q=update.callback_query; a=q.data.split(":"); typ=a[0]; gid=a[1]; target=int(a[2]) if len(a)>2 else None
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g["phase"]!="voting":return await cb_answer(q,"Ovoz berish tugagan.",True)
    voter=getp(g,q.from_user.id)
    if not voter or not voter["alive"]:return await cb_answer(q,"Siz tirik emassiz.",True)
    if q.from_user.id in g["votes"]:return await cb_answer(q,"Ovozingiz allaqachon qabul qilingan.",True)
    if typ=="vote":
        t=getp(g,target)
        if not t or not t["alive"]:return await cb_answer(q,"Nishon mavjud emas.",True)
        g["votes"][q.from_user.id]=target; persist_games(); await cb_answer(q,"Ovoz qabul qilindi.")
    else:g["votes"][q.from_user.id]=None; await cb_answer(q,"Ovoz bermaslik tanlandi.")

async def resolve_vote(ctx):
    d=ctx.job.data; chat_id=next((cid for cid,g in games.items() if g["id"]==d["gid"]),None)
    if chat_id is None:return
    g=games[chat_id]
    if not valid_job(g,d) or g["phase"]!="voting":return
    counts={}
    for target in g["votes"].values():
        if target is not None: counts[target]=counts.get(target,0)+1
    if not counts:
        await ctx.bot.send_message(g["chat_id"],"🗳 Ovoz berilmadi."); return await after_vote(ctx.application,g)
    mx=max(counts.values()); top=[uid for uid,c in counts.items() if c==mx]
    if len(top)>1:
        await ctx.bot.send_message(g["chat_id"],"🤝 Ovozlar teng bo‘ldi. Hech kim osilmadi."); return await after_vote(ctx.application,g)
    victim=getp(g,top[0])
    if victim["hanging_protected"]:
        victim["hanging_protected"]=False; consume_inventory(victim,"hanging_protection")
        await ctx.bot.send_message(g["chat_id"],f"🛡 {mention(victim)} osilishdan himoyalangan edi."); return await after_vote(ctx.application,g)
    kill_player(victim,"vote")
    await ctx.bot.send_message(g["chat_id"],f"⚖️ {mention(victim)} ovoz bilan o‘yindan chiqarildi.")
    if victim["role"]=="Suidsid":
        await ctx.bot.send_message(g["chat_id"],"🪢 Suidsid o‘zining g‘alaba shartini bajardi."); g["forced_winners"]=[victim]
    await after_vote(ctx.application,g)

async def after_vote(app,g):
    if g.get("forced_winners"):
        return await end_game(app,g,g["forced_winners"])
    if game_over(g): return await end_game(app,g)
    g["night"]+=1; await start_night(app,g)

# ---------------- SPECIAL CALLBACKS ----------------
async def cb_af(update,ctx):
    q=update.callback_query; parts=q.data.split(":")
    if len(parts)!=5: return await cb_answer(q,"Bu qaror mavjud emas.",True)
    _,gid,afid,attid,decision=parts
    g=next((x for x in games.values() if x.get("id")==gid),None)
    if not g or q.from_user.id!=int(afid) or g.get("phase") not in {"night","afsungar"}: return await cb_answer(q,"Bu qaror mavjud emas.",True)
    a=getp(g,int(attid)); af=getp(g,int(afid))
    if not af or not a or not af.get("alive") or af.get("role")!="Afsungar": return await cb_answer(q,"O‘yinchi topilmadi.",True)
    if int(attid) not in af.get("afsungar_decisions",{}): return await cb_answer(q,"Bu hujum topilmadi.",True)
    if af["afsungar_decisions"].get(int(attid)) is not None: return await cb_answer(q,"Qaror allaqachon tanlangan.",True)
    af["afsungar_decisions"][int(attid)]=decision
    await safe_edit(q,("🕊️ Kechirish" if decision=="forgive" else "☠️ O‘ldirish")+" tanlandi. Natija tongda qo‘llanadi.",None); await cb_answer(q,"Qaror saqlandi.")

async def cb_folbin_msg(update,ctx):
    q=update.callback_query; a=q.data.split(":")
    if a[0]=="cancel_f": return await safe_edit(q,"❌ Xabar bekor qilindi.",None)
    if len(a)!=4: return await cb_answer(q,"Xabar mavjud emas.",True)
    _,gid,target,result=a
    g=next((x for x in games.values() if x.get("id")==gid),None)
    if not g or q.from_user.id not in [p["id"] for p in g.get("players",{}).values() if p.get("role")=="Komissar Katani"]:
        return await cb_answer(q,"Bu xabar siz uchun emas.",True)
    p=getp(g,int(target))
    if not p: return await cb_answer(q,"O‘yinchi topilmadi.",True)
    await safe_edit(q,f"🧿 Folbin yarim tunda o‘z sehrini ishga soldi va {mention(p)}ning {result} ekanini aniqladi.",None)

async def end_game(app,g,forced=None):
    if g.get("ended"): return
    cancel_jobs(g); g["ended"]=True; g["phase"]="ended"; g["phase_id"]+=1
    win=forced if forced is not None else winners(g)
    win_ids={p["id"] for p in win}
    for p in win: add_stats(p["id"],win=True)
    elapsed=max(0,int(time.time()-(g.get("start_time") or time.time())))
    mm,ss=divmod(elapsed,60)
    lines=["O’yin tugadi!","","G’oliblar:"]
    if win:
        for i,p in enumerate(win,1): lines.append(f"{i}. {mention(p)} — {role_label(p['role'])}")
    else: lines.append("—")
    lines += ["","Qolgan o’yinchilar:"]
    remaining=[p for p in g["players"].values() if p["id"] not in win_ids]
    if remaining:
        for i,p in enumerate(remaining,1): lines.append(f"{i}. {mention(p)} — {role_label(p['role'])}")
    else: lines.append("—")
    lines += ["",f"O’yin davomiyligi: {mm:02d} daqiqa {ss:02d} soniya"]
    await app.bot.send_message(g["chat_id"],"\n".join(lines),parse_mode=ParseMode.HTML)
    games.pop(g.get("chat_id"), None)
    persist_games()

# ---------------- ADMIN / STOP ----------------
async def cmd_stop(update,ctx):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}:return
    if update.effective_user.id!=ADMIN_ID:
        return await update.message.reply_text("❌ Bu buyruq faqat admin uchun.")
    g=games.get(update.effective_chat.id)
    if not g or g.get("phase") in {"ended","cancelled"}: return await update.message.reply_text("ℹ️ Faol o‘yin yo‘q.")
    cancel_jobs(g); g["phase"]="cancelled"; g["ended"]=True; await update.message.reply_text("🛑 O‘yin admin tomonidan to‘xtatildi.")

async def cmd_admin(update,ctx):
    if update.effective_user.id!=ADMIN_ID:return
    r=get_user(ADMIN_ID)
    await update.message.reply_text(f"🛠 Admin\nFaol o‘yinlar: {sum(1 for g in games.values() if g.get('phase') not in {'ended','cancelled'})}\nDB: {DB_FILE}\nPTB: 20+ API")

# ---------------- ERRORS / START ----------------
