async def cmd_ugame(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    return await create_lobby(update,ctx,"uniform",None)

async def cmd_zgame(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    return await create_lobby(update,ctx,"zombie",None)

async def cmd_game(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    return await create_lobby(update,ctx)

async def cmd_ngame(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    raw=(update.message.text or "").split(maxsplit=1)
    if len(raw)<2 or not raw[1].strip():
        return await update.message.reply_text("❌ /ngame dan keyin nom, belgi, emoji yoki boshqa qiymat yozing.")
    return await create_lobby(update,ctx,"name",raw[1].strip())


async def finish_lobby(ctx:ContextTypes.DEFAULT_TYPE):
    d=ctx.job.data; chat_id=next((cid for cid,g in games.items() if g["id"]==d["gid"]),None)
    if chat_id is None:return
    g=games[chat_id]
    if not valid_job(g,d) or g["phase"]!="lobby": return
    if len(g["players"])<MIN_PLAYERS:
        g["phase"]="cancelled"; cancel_jobs(g)
        try: await ctx.bot.edit_message_text(chat_id,g["lobby_message_id"],"🛑 O‘yinchilar soni yetarli emasligi sabab o'yin bekor qilindi.")
        except TelegramError: pass
        return
    if g.get("mode") == "vs":
        teams=int(g.get("mode_state",{}).get("teams_count",2))
        active_teams={p.get("team") for p in g["players"].values() if p.get("team")}
        if len(active_teams) < teams:
            g["phase"]="cancelled"; cancel_jobs(g)
            try: await ctx.bot.edit_message_text(chat_id,g["lobby_message_id"],"❌ VS o‘yini bekor qilindi. Har bir jamoada kamida 1 ta o‘yinchi bo‘lishi kerak.")
            except TelegramError: pass
            return
    await start_game(ctx.application,g)

async def cb_join(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    q=update.callback_query; await cb_answer(q)
    gid=q.data.split(":",1)[1]
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g.get("phase")!="lobby": return await cb_answer(q,"Lobby yopilgan.",True)
    if len(g.get("players",{}))>=MAX_PLAYERS: return await cb_answer(q,"O‘yin to‘ldi.",True)
    me=await ctx.bot.get_me()
    link=f"https://t.me/{me.username}?start=join_{g['chat_id']}_{g['id']}"
    await q.message.reply_text("🎭 O‘yinga qo‘shilish uchun botning shaxsiy chatiga o‘ting.",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🤖 Botga o‘tish",url=link)]]))

async def cmd_vsgame(update:Update,ctx:ContextTypes.DEFAULT_TYPE, teams_override=None):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    raw=(update.message.text or "").strip().lower()
    teams=teams_override
    if teams is None:
        tail=raw[len("/vsgame"):].strip()
        if tail.isdigit(): teams=int(tail)
        elif ctx.args and ctx.args[0].isdigit(): teams=int(ctx.args[0])
        else: teams=2
    if not 2 <= teams <= 9:
        return await update.message.reply_text("❌ VS mode jamoalari 2–9 oralig‘ida bo‘lishi kerak.")
    return await create_lobby(update,ctx,"vs",teams)

def vs_team_capacity(g):
    teams=int(g.get("mode_state",{}).get("teams_count",2))
    teams=max(2,min(9,teams))
    return math.ceil(MAX_PLAYERS/teams)

async def join_vs_deeplink(update:Update,ctx:ContextTypes.DEFAULT_TYPE,token_value:str):
    parts=token_value.split("_")
    if len(parts)!=3 or parts[0]!="vsgame": return False
    gid,team=parts[1],parts[2].lower()
    g=find_game(gid)
    if not g or g.get("mode")!="vs" or g.get("phase")!="lobby":
        await update.message.reply_text("❌ VS lobby topilmadi yoki yopilgan.")
        return True
    if team not in VS_TEAM_COLORS:
        await update.message.reply_text("❌ Bunday VS jamoasi mavjud emas.")
        return True
    allowed=set(list(VS_TEAM_COLORS.keys())[:int(g.get("mode_state",{}).get("teams_count",2))])
    if team not in allowed:
        await update.message.reply_text("❌ Bu jamoa ushbu VS o‘yinida mavjud emas.")
        return True
    uid=update.effective_user.id; ensure_user(update.effective_user)
    p=getp(g,uid)
    max_team=vs_team_capacity(g)
    current=[x for x in g["players"].values() if x.get("alive") and x.get("team")==team]
    if len(current)>=max_team and (not p or p.get("team")!=team):
        await update.message.reply_text("❌ Bu jamoa to‘lgan.")
        return True
    if p and p.get("alive"):
        p["team"]=team
        await update.message.reply_text(f"✅ Siz {VS_TEAM_COLORS[team]} jamoaga qo‘shildingiz.")
    else:
        g["players"][uid]=new_player(update.effective_user); g["players"][uid]["team"]=team
        await update.message.reply_text(f"✅ Siz {VS_TEAM_COLORS[team]} jamoaga qo‘shildingiz.")
    me=await ctx.bot.get_me()
    try:
        await ctx.bot.edit_message_text(g["chat_id"],g["lobby_message_id"],vs_lobby_text(g),reply_markup=lobby_markup(g,me.username or ""),parse_mode=ParseMode.HTML)
    except TelegramError: pass
    persist_games()
    return True

# ---------------- BOUNTY / MODES ----------------
async def cmd_bounty(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    g=games.get(update.effective_chat.id)
    if not g or g.get("phase") in {"lobby","ended","cancelled"}:
        return await update.message.reply_text("❌ Bounty faqat faol o‘yin vaqtida ishlaydi.")
    reply=update.message.reply_to_message
    if not reply or not reply.from_user: return await update.message.reply_text("❌ Bounty qo‘yish uchun o‘yinchi xabariga reply qiling.")
    try: amount=int((ctx.args or [])[0])
    except (ValueError,IndexError): return await update.message.reply_text("❌ Foydalanish: /bounty <pul>")
    if amount<=0 or amount>10_000_000: return await update.message.reply_text("❌ Pul miqdori 1–10 000 000 oralig‘ida bo‘lishi kerak.")
    target=getp(g,reply.from_user.id)
    owner=getp(g,update.effective_user.id)
    if not target or not target["alive"]: return await update.message.reply_text("❌ Bounty faqat tirik o‘yinchiga qo‘yiladi.")
    if not owner or not owner["alive"]: return await update.message.reply_text("❌ Faqat tirik o‘yinchi bounty qo‘ya oladi.")
    con=db()
    try:
        con.execute("BEGIN IMMEDIATE")
        row=con.execute("SELECT money FROM users WHERE user_id=?",(owner["id"],)).fetchone()
        if not row or row[0]<amount:
            con.rollback(); return await update.message.reply_text("❌ Hisobingizda yetarli mablag‘ mavjud emas.")
        con.execute("UPDATE users SET money=money-? WHERE user_id=? AND money>=?",(amount,owner["id"],amount))
        if con.total_changes != 1:
            con.rollback(); return await update.message.reply_text("❌ Hisobingizda yetarli mablag‘ mavjud emas.")
        con.commit()
    finally:
        con.close()
    g.setdefault("bounties",[]).append({"owner":owner["id"],"target":target["id"],"amount":amount,"created":time.time()})
    persist_games()
    await update.message.reply_text(f"🎯 {visible_name(g,target)}ni o‘ldirganga {amount}💷 mukofot beriladi!")

def modes_keyboard():
    return InlineKeyboardMarkup([[InlineKeyboardButton("🏷️ Name mode",callback_data="mode:name")],[InlineKeyboardButton("🎭 Uniform mode",callback_data="mode:uniform")],[InlineKeyboardButton("🧟 Zombie mode",callback_data="mode:zombie")],[InlineKeyboardButton("⚔️ VS mode",callback_data="mode:vs")]])

def mode_detail(mode):
    texts={
      "name":"🏷️ <b>Name mode</b>\n\nBu modeni tanlasangiz, o‘yindagi hamma ishtirokchining ismlari bir xil bo‘lib qoladi.",
      "uniform":"🎭 <b>Uniform mode</b>\n\nBu modeni tanlasangiz, hammaga random tarzda bir xil killer rol beriladi. O‘yinda faqat 1 o‘yinchi tirik qolguncha davom etadi va oxirgi tirik o‘yinchi g‘olib bo‘ladi.",
      "zombie":"🧟 <b>Zombie mode</b>\n\nButun o‘yin uchun bitta Zombi bo‘ladi. Har tun u bitta tirik o‘yinchini tanlaydi. Tanlangan o‘yinchi tongdan 5 soniya oldin Zombi bo‘lgani haqida shaxsiy xabar oladi va keyingi tundan Zombi tarafida o‘ynaydi. O‘yin Zombilar yoki qolganlar tomonlaridan biri tugaguncha davom etadi.",
      "vs":"⚔️ <b>VS mode</b>\n\nYangi VS tizimida 2–9 ta jamoa bo‘ladi. Jamoalar ranglar bilan belgilanadi. O‘yinchilar shaxsiy chatdagi rang tugmasi orqali jamoa tanlaydi va lobby davomida jamoasini almashtira oladi. Faqat bitta jamoa tirik qolsa, shu jamoa g‘olib bo‘ladi.\n\n▶️ Boshlash: <code>/vsgame 2</code> yoki <code>/vsgame3</code>"}
    return texts[mode]

async def cmd_modes(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    member=await ctx.bot.get_chat_member(update.effective_chat.id,update.effective_user.id)
    if member.status not in {"administrator","creator"}: return await update.message.reply_text("❌ Bu buyruq faqat guruh adminlari uchun.")
    try: await update.message.delete()
    except TelegramError: pass
    await ctx.bot.send_message(update.effective_chat.id,"🎮 <b>Marhamat, kerakli mode'ni tanlang.</b>",reply_markup=modes_keyboard(),parse_mode=ParseMode.HTML)

async def cb_mode(update,ctx):
    q=update.callback_query
    if q.message.chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return await cb_answer(q,"Faqat guruhda.",True)
    member=await ctx.bot.get_chat_member(q.message.chat.id,q.from_user.id)
    if member.status not in {"administrator","creator"}: return await cb_answer(q,"Faqat guruh admini tanlay oladi.",True)
    key=q.data.split(":",1)[1]
    if key=="back": return await safe_edit(q,"🎮 <b>Marhamat, kerakli mode'ni tanlang.</b>",modes_keyboard())
    return await safe_edit(q,mode_detail(key),InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Ortga",callback_data="mode:back")]]))

# ---------------- START / MENUS ----------------
