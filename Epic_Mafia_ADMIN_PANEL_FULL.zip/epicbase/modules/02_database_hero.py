def db():
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = db(); cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', first_name TEXT DEFAULT '',
        money INTEGER DEFAULT 0, diamonds INTEGER DEFAULT 0, coins INTEGER DEFAULT 0,
        wins INTEGER DEFAULT 0, games INTEGER DEFAULT 0, inventory TEXT DEFAULT '{}',
        protection INTEGER DEFAULT 0, fake_document INTEGER DEFAULT 0, hanging_protection INTEGER DEFAULT 0,
        rifle INTEGER DEFAULT 0, mask INTEGER DEFAULT 0, supper_shield INTEGER DEFAULT 0, active_role INTEGER DEFAULT 0,
        hero_protection INTEGER DEFAULT 0, medicine_protection INTEGER DEFAULT 0, first_start_granted INTEGER DEFAULT 0
    )""")
    # Safe migrations for databases created by older Epic Mafia builds.
    existing={r[1] for r in cur.execute("PRAGMA table_info(users)").fetchall()}
    for col in ["protection","fake_document","hanging_protection","rifle","mask","supper_shield","active_role","hero_protection","medicine_protection"]:
        if col not in existing:
            cur.execute(f"ALTER TABLE users ADD COLUMN {col} INTEGER DEFAULT 0")
    # Migrate legacy JSON inventory once; the canonical inventory is now stored in dedicated columns.
    legacy_rows=cur.execute("SELECT user_id, inventory FROM users WHERE inventory IS NOT NULL AND inventory!='{}'").fetchall()
    for lr in legacy_rows:
        try: old=json.loads(lr[1] or "{}")
        except Exception: old={}
        if not old: continue
        vals={k:max(0,int(old.get(k,0))) for k in ("protection","fake_document","hanging_protection","rifle","mask","supper_shield","active_role","hero_protection","medicine_protection")}
        cur.execute("UPDATE users SET "+",".join(f"{k}=MAX({k},?)" for k in vals)+" WHERE user_id=?",(*vals.values(),lr[0]))
    cur.execute("""CREATE TABLE IF NOT EXISTS heroes(
        user_id INTEGER PRIMARY KEY, name TEXT DEFAULT 'Nomsiz', level INTEGER DEFAULT 1,
        ball INTEGER DEFAULT 0, patron INTEGER DEFAULT 10, shield INTEGER DEFAULT 0,
        created_at REAL DEFAULT 0
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS hero_market(
        id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id INTEGER NOT NULL, price INTEGER NOT NULL,
        active INTEGER DEFAULT 1, created_at REAL DEFAULT 0
    )""")
    con.commit(); con.close()

def ensure_user(u):
    con=db(); cur=con.cursor()
    cur.execute("SELECT user_id FROM users WHERE user_id=?", (u.id,))
    if not cur.fetchone():
        cur.execute("INSERT INTO users(user_id,username,first_name) VALUES(?,?,?)", (u.id,u.username or '',u.first_name or ''))
    else:
        cur.execute("UPDATE users SET username=?,first_name=? WHERE user_id=?", (u.username or '',u.first_name or '',u.id))
    con.commit(); con.close()

def get_user(uid):
    con=db(); r=con.execute("SELECT * FROM users WHERE user_id=?",(uid,)).fetchone(); con.close(); return r

def grant_first_start(uid):
    con=db()
    try:
        con.execute("BEGIN IMMEDIATE")
        cur=con.execute("UPDATE users SET money=money+1000, first_start_granted=1 WHERE user_id=? AND first_start_granted=0",(uid,))
        if cur.rowcount==1:
            con.commit(); return True
        con.rollback(); return False
    finally:
        con.close()

def add_stats(uid, game=False, win=False):
    con=db();
    if game: con.execute("UPDATE users SET games=games+1 WHERE user_id=?",(uid,))
    if win: con.execute("UPDATE users SET wins=wins+1 WHERE user_id=?",(uid,))
    con.commit(); con.close()

def inv(uid):
    r=get_user(uid)
    if not r: return {}
    keys=("protection","fake_document","hanging_protection","rifle","mask","supper_shield","active_role","hero_protection","medicine_protection")
    return {k:int(r[k] or 0) for k in keys}

def set_inv(uid, d):
    keys=("protection","fake_document","hanging_protection","rifle","mask","supper_shield","active_role","hero_protection","medicine_protection")
    values=[max(0,int(d.get(k,0))) for k in keys]
    con=db(); con.execute("UPDATE users SET "+",".join(f"{k}=?" for k in keys)+" WHERE user_id=?",(*values,uid)); con.commit(); con.close()

def buy(uid, item, cost_type, cost):
    if cost_type not in {"money", "diamonds"}: return False,"Noto‘g‘ri valyuta"
    con=db()
    try:
        con.execute("BEGIN IMMEDIATE")
        r=con.execute(f"SELECT {cost_type}, {item} FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r: con.rollback(); return False,"Foydalanuvchi topilmadi"
        bal=int(r[0] or 0)
        if bal<cost: con.rollback(); return False,"Sizda yetarli resurs mavjud emas❌"
        con.execute(f"UPDATE users SET {cost_type}={cost_type}-?, {item}={item}+1 WHERE user_id=?",(cost,uid))
        con.commit(); return True,"OK"
    except Exception:
        con.rollback(); raise
    finally:
        con.close()

# ---------------- HERO / PERSONAL META SYSTEM ----------------
HERO_PRICE = 90                 # diamond
HERO_BALL_PRICE = 50            # diamond -> +1000 ball
HERO_SHIELD_BASE = 64            # Epic Coin + level*100
HERO_GUN_BASE = 95               # Epic Coin + level*100
HERO_NAME_PRICE = 780             # Epic Coin
HERO_PROTECTION_PRICE = 7         # diamond
HERO_MARKET_FEE = 5               # diamond

def hero_row(uid):
    con=db(); r=con.execute("SELECT * FROM heroes WHERE user_id=?",(uid,)).fetchone(); con.close(); return r

def ensure_hero(uid, name="Nomsiz"):
    if hero_row(uid): return
    con=db(); con.execute("INSERT INTO heroes(user_id,name,created_at) VALUES(?,?,?)",(uid,name,time.time())); con.commit(); con.close()

def hero_max_shield(level):
    return int(10 * (level / 1.2))

def hero_level(ball):
    return max(1, int(ball)//1100 + 1)

def hero_damage_range(level):
    lo=40+(level-1)*7; hi=40+level*7
    return (100,100) if lo>=100 else (lo,hi)

def hero_text(uid):
    h=hero_row(uid)
    if not h: return "🥷 <b>Geroy</b>\n\nSizda hozircha Geroy yo‘q."
    lo,hi=hero_damage_range(h["level"])
    dmg="maksimal" if lo>=100 else f"{lo}–{hi}"
    return (f"🥷 <b>Geroy:</b> {html.escape(str(h['name']))}\n\n"
            f"⭐️ <b>Daraja:</b> {h['level']}\n"
            f"👊 <b>Kuch:</b> {dmg}\n"
            f"🖤 <b>Himoya:</b> {h['shield']} / {hero_max_shield(h['level'])}\n"
            f"🩸 <b>Zaryad:</b> {h['patron']} / 10\n"
            f"☑️ <b>Ball:</b> {h['ball']}\n"
            f"⏫ <b>Keyingi daraja:</b> {h['level']+1} → {1100*h['level']} ball")

def hero_menu_markup(uid):
    if not hero_row(uid):
        return InlineKeyboardMarkup([[InlineKeyboardButton("🥷 Geroy sotib olish — 90💎",callback_data="hero:buy")],
                                     [InlineKeyboardButton("🔙 Orqaga",callback_data="menu:home")]])
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ 1000 Ball",callback_data="hero:ball"), InlineKeyboardButton("🛡 Himoyani yangilash",callback_data="hero:shield")],
        [InlineKeyboardButton("🩸 Qurolni o‘qlash",callback_data="hero:gun")],
        [InlineKeyboardButton("🖋 Nomini o‘zgartirish",callback_data="hero:name")],
        [InlineKeyboardButton("⭐️ Darajalar haqida",callback_data="hero:levels")],
        [InlineKeyboardButton("🛒 Geroy Market",callback_data="hero:market")],
        [InlineKeyboardButton("🔙 Orqaga",callback_data="menu:profile")],
    ])

def hero_market_markup():
    con=db(); rows=con.execute("SELECT id,seller_id,price FROM hero_market WHERE active=1 ORDER BY id DESC LIMIT 20").fetchall(); con.close()
    kb=[]
    for r in rows:
        h=hero_row(r["seller_id"])
        if h:
            kb.append([InlineKeyboardButton(f"🥷 {h['name']} • Lv.{h['level']} • {r['price']}💎",callback_data=f"hero:listing:{r['id']}")])
    kb.append([InlineKeyboardButton("➕ Geroyimni sotuvga qo‘yish",callback_data="hero:list")])
    kb.append([InlineKeyboardButton("🔙 Orqaga",callback_data="menu:hero")])
    return InlineKeyboardMarkup(kb)

async def show_hero(q, uid):
    await safe_edit(q, hero_text(uid), hero_menu_markup(uid))

async def hero_buy(q):
    uid=q.from_user.id
    con=db()
    try:
        con.execute("BEGIN IMMEDIATE")
        if con.execute("SELECT 1 FROM heroes WHERE user_id=?",(uid,)).fetchone():
            con.rollback(); return await cb_answer(q,"Sizda Geroy allaqachon mavjud.",True)
        r=con.execute("SELECT diamonds FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r or r[0] < HERO_PRICE:
            con.rollback(); return await cb_answer(q,"Sizda yetarli 💎 mavjud emas❌",True)
        con.execute("UPDATE users SET diamonds=diamonds-? WHERE user_id=?",(HERO_PRICE,uid))
        con.execute("INSERT INTO heroes(user_id,name,created_at) VALUES(?,?,?)",(uid,"Nomsiz",time.time()))
        con.commit()
    except sqlite3.IntegrityError:
        con.rollback(); return await cb_answer(q,"Sizda Geroy allaqachon mavjud.",True)
    finally:
        con.close()
    await q.message.edit_text(hero_text(uid),reply_markup=hero_menu_markup(uid),parse_mode=ParseMode.HTML)
    await cb_answer(q,"Geroy xarid qilindi✅",True)

async def hero_callback(update,ctx):
    q=update.callback_query
    if q.message.chat.type!=ChatType.PRIVATE: return await cb_answer(q,"Faqat shaxsiy chatda.",True)
    uid=q.from_user.id; a=q.data.split(":"); action=a[1] if len(a)>1 else ""
    h=hero_row(uid)
    if action=="buy": return await hero_buy(q)
    if action=="menu": return await show_hero(q,uid)
    if action=="market":
        return await safe_edit(q,"🛒 <b>Geroy Market</b>\n\nSotuvdagi Geroylarni tanlang:",hero_market_markup())
    if action=="listing" and len(a)==3:
        con=db(); row=con.execute("SELECT * FROM hero_market WHERE id=? AND active=1",(int(a[2]),)).fetchone(); con.close()
        if not row: return await cb_answer(q,"Bu e’lon mavjud emas.",True)
        if row["seller_id"]==uid: return await cb_answer(q,"O‘zingizning Geroyingizni sotib olmaysiz.",True)
        seller_h=hero_row(row["seller_id"])
        if not seller_h: return await cb_answer(q,"Geroy topilmadi.",True)
        kb=InlineKeyboardMarkup([[InlineKeyboardButton(f"💎 {row['price']} ga sotib olish",callback_data=f"hero:buylisting:{row['id']}")],[InlineKeyboardButton("🔙 Orqaga",callback_data="hero:market")]])
        return await safe_edit(q,hero_text(row["seller_id"]) + f"\n\n💎 <b>Narxi:</b> {row['price']}",kb)
    if action=="buylisting" and len(a)==3:
        con=db(); row=con.execute("SELECT * FROM hero_market WHERE id=? AND active=1",(int(a[2]),)).fetchone(); con.close()
        if not row: return await cb_answer(q,"Bu Geroy allaqachon sotilgan.",True)
        if row["seller_id"]==uid: return await cb_answer(q,"O‘zingizning Geroyingizni sotib olmaysiz.",True)
        if hero_row(uid): return await cb_answer(q,"Avval o‘zingizdagi Geroyni boshqa yo‘l bilan topshirishingiz kerak.",True)
        con=db()
        try:
            con.execute("BEGIN IMMEDIATE")
            row2=con.execute("SELECT * FROM hero_market WHERE id=? AND active=1",(int(a[2]),)).fetchone()
            if not row2:
                con.rollback(); return await cb_answer(q,"Bu Geroy allaqachon sotilgan.",True)
            price=int(row2["price"]); seller=int(row2["seller_id"])
            bal=con.execute("SELECT diamonds FROM users WHERE user_id=?",(uid,)).fetchone()
            if not bal or bal[0] < price:
                con.rollback(); return await cb_answer(q,"Sizda yetarli 💎 mavjud emas❌",True)
            if con.execute("SELECT 1 FROM heroes WHERE user_id=?",(uid,)).fetchone():
                con.rollback(); return await cb_answer(q,"Avval o‘zingizdagi Geroyni topshiring.",True)
            con.execute("UPDATE users SET diamonds=diamonds-? WHERE user_id=?",(price,uid))
            con.execute("UPDATE users SET diamonds=diamonds+? WHERE user_id=?",(max(0,price-HERO_MARKET_FEE),seller))
            con.execute("UPDATE heroes SET user_id=? WHERE user_id=?",(uid,seller))
            con.execute("UPDATE hero_market SET active=0 WHERE id=? AND active=1",(row2["id"],))
            con.commit()
        finally:
            con.close()
        try: await ctx.bot.send_message(seller,f"🥷 Geroyingiz {q.from_user.full_name} tomonidan {price}💎 ga sotib olindi.")
        except Exception: pass
        return await show_hero(q,uid)
    if not h: return await cb_answer(q,"🥷 Sizda Geroy mavjud emas.",True)
    if action=="ball":
        con=db(); r=con.execute("SELECT diamonds FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r or r[0] < HERO_BALL_PRICE: con.close(); return await cb_answer(q,"Sizda yetarli 💎 mavjud emas❌",True)
        ball=h["ball"]+1000; lvl=hero_level(ball)
        con.execute("UPDATE users SET diamonds=diamonds-? WHERE user_id=?",(HERO_BALL_PRICE,uid)); con.execute("UPDATE heroes SET ball=?,level=? WHERE user_id=?",(ball,lvl,uid)); con.commit(); con.close()
        return await show_hero(q,uid)
    if action=="shield":
        cost=HERO_SHIELD_BASE+h["level"]*100; mx=hero_max_shield(h["level"])
        if h["shield"]>=mx: return await cb_answer(q,"Geroyingizda maksimal himoya bor.",True)
        con=db(); r=con.execute("SELECT money FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r or r[0]<cost: con.close(); return await cb_answer(q,"Sizda yetarli 💷 mavjud emas❌",True)
        con.execute("UPDATE users SET money=money-? WHERE user_id=?",(cost,uid)); con.execute("UPDATE heroes SET shield=? WHERE user_id=?",(mx,uid)); con.commit(); con.close()
        return await show_hero(q,uid)
    if action=="gun":
        cost=HERO_GUN_BASE+h["level"]*100
        if h["patron"]>=10: return await cb_answer(q,"Geroyingizda maksimal zaryad bor.",True)
        con=db(); r=con.execute("SELECT money FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r or r[0]<cost: con.close(); return await cb_answer(q,"Sizda yetarli 💷 mavjud emas❌",True)
        con.execute("UPDATE users SET money=money-? WHERE user_id=?",(cost,uid)); con.execute("UPDATE heroes SET patron=10 WHERE user_id=?",(uid,)); con.commit(); con.close()
        return await show_hero(q,uid)
    if action=="name":
        ctx.user_data["hero_rename_pending"]=True
        return await safe_edit(q,"🖋 Yangi Geroy nomini oddiy xabar qilib yuboring.\n\n💷 Narxi: 780",InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Orqaga",callback_data="hero:menu")]]))
    if action=="levels":
        lines=["⭐️ <b>Geroy darajalari</b>",""]
        for i in range(1,13):
            lo,hi=hero_damage_range(i); dmg="maksimal" if lo>=100 else f"{lo}–{hi}"
            lines.append(f"⭐️ {i}-daraja — {1100*(i-1)} ball — 👊 {dmg} — 🖤 Max himoya {hero_max_shield(i)}")
        return await safe_edit(q,"\n".join(lines),InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Orqaga",callback_data="hero:menu")]]))
    if action=="list":
        if ctx.user_data.get("hero_market_pending"): return await cb_answer(q,"Avval narx yuboring.",True)
        ctx.user_data["hero_market_pending"]=True
        return await safe_edit(q,"🛒 Geroyingizni sotuvga qo‘yish uchun narxni 💎 bilan yuboring.\n\nMinimal narx: 20💎\nSavdodan 5💎 ushlab qolinadi.",InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Bekor qilish",callback_data="hero:menu")]]))
    return await cb_answer(q)

async def hero_private_text(update,ctx):
    if update.effective_chat.type!=ChatType.PRIVATE or not update.message or not update.message.text: return False
    uid=update.effective_user.id; text=update.message.text.strip()
    if ctx.user_data.get("hero_rename_pending"):
        h=hero_row(uid)
        if not h: ctx.user_data.pop("hero_rename_pending",None); return False
        con=db(); r=con.execute("SELECT money FROM users WHERE user_id=?",(uid,)).fetchone()
        if not r or r[0]<HERO_NAME_PRICE:
            con.close(); await update.message.reply_text("Sizda yetarli 💷 mavjud emas❌"); return True
        if not 2<=len(text)<=24:
            await update.message.reply_text("Geroy nomi 2–24 belgidan iborat bo‘lsin."); return True
        con.execute("UPDATE users SET money=money-? WHERE user_id=?",(HERO_NAME_PRICE,uid)); con.execute("UPDATE heroes SET name=? WHERE user_id=?",(text,uid)); con.commit(); con.close()
        ctx.user_data.pop("hero_rename_pending",None); await update.message.reply_text("✅ Geroy nomi o‘zgartirildi!"); return True
    if ctx.user_data.get("hero_market_pending"):
        try: price=int(text)
        except ValueError: await update.message.reply_text("Narxni butun son ko‘rinishida yuboring."); return True
        if price<20: await update.message.reply_text("Minimal narx 20💎."); return True
        if not hero_row(uid): ctx.user_data.pop("hero_market_pending",None); return False
        con=db(); exists=con.execute("SELECT id FROM hero_market WHERE seller_id=? AND active=1",(uid,)).fetchone()
        if exists: con.close(); ctx.user_data.pop("hero_market_pending",None); await update.message.reply_text("Sizning Geroyingiz allaqachon Marketda."); return True
        con.execute("INSERT INTO hero_market(seller_id,price,created_at) VALUES(?,?,?)",(uid,price,time.time())); con.commit(); con.close(); ctx.user_data.pop("hero_market_pending",None)
        await update.message.reply_text("✅ Geroyingiz Geroy Marketga qo‘yildi!",reply_markup=hero_market_markup()); return True
    return False

# ---------------- GAME ENGINE ----------------
games = {}

