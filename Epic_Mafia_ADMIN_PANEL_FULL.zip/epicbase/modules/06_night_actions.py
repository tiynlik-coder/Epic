async def start_game(app,g):
    if g["phase"]!="lobby": return
    cancel_jobs(g); g["phase"]="starting"; g["phase_id"]+=1; g["start_time"]=time.time()
    if g.get("mode") == "uniform":
        killer_pool=sorted(ORDINARY_KILLERS | {"Snayper","Professor","Minior"})
        chosen=random.choice(killer_pool)
        role_list=[chosen]*len(g["players"])
        g["mode_state"]={"uniform_role":chosen}
    elif g.get("mode") == "vs":
        role_list=role_balance(len(g["players"]))
        g["mode_state"]["teams_count"]=int(g.get("mode_state",{}).get("teams_count",2))
    elif g.get("mode") == "zombie":
        role_list=role_balance(len(g["players"]))
        g["mode_state"]={"zombie_ids":[],"zombie_pending":None}
    else:
        role_list=role_balance(len(g["players"]))
        if len(g["players"])==30: role_list=ROLES[:]; random.shuffle(role_list)
    role_list=apply_admin_roles(g, role_list)
    for p,r in zip(g["players"].values(),role_list):
        p["role"]=r; p["alive"]=True; p["base_hp"]=150 if r=="Tabib" else 100; p["max_hp"]=p["base_hp"]; p["hp"]=p["base_hp"]; p["temp_hp_bonus"]=0
        d=inv(p["id"])
        p["protected"]=d.get("protection",0)>0
        p["hanging_protected"]=d.get("hanging_protection",0)>0
        p["supper"]=d.get("supper_shield",0)>0
        p["mask"]=d.get("mask",0)>0
        p["fake_document"]=d.get("fake_document",0)>0
        p["hero_protection"]=d.get("hero_protection",0)>0
        add_stats(p["id"],game=True)
        intro=ROLE_INTRO.get(r,f"{EMOJI.get(r,'🎭')} Siz — {r}siz!\nSiz {side(r)} tarafdasiz.")
        if g.get("mode") == "vs":
            intro += f"\n\n⚔️ Sizning jamoangiz: {team_icon(p)}"
        await send_private(app.bot,p["id"],intro)
    if g.get("mode") == "zombie":
        first=random.choice(living(g))
        first["role"]="Zombi"
        g["mode_state"]["zombie_ids"]=[first["id"]]
        await send_private(app.bot,first["id"],"🧟 Siz — Zombisiz!\nSiz Zombie tarafidasiz. Har tun bir o‘yinchini Zombi qilishingiz mumkin.")
        await send_zombie_rosters(app.bot,g)
    await app.bot.send_message(g["chat_id"],"⚔️ <b>VS O‘YIN BOSHLANDI!</b>" if g.get("mode")=="vs" else "🎭 <b>O‘YIN BOSHLANDI!</b>",parse_mode=ParseMode.HTML)
    g["phase"]="night"; g["phase_id"]+=1; g["night"]=1; await start_night(app,g)

async def start_night(app,g):
    if g["ended"]: return
    cancel_jobs(g); g["phase"]="night"; g["phase_id"]+=1
    pending=g.get("next_ability_swaps", {})
    for p in g["players"].values():
        p["action"]=None; p["hero_action"]=None; p["visits"]=[]; p["blocked"]=False; p["afsungar_decisions"]={}; p["last_attackers"]=[]
        p["temp_ability"]=pending.get(str(p["id"]))
        p["temp_hp_bonus"]=0; p["advokat_result"]=False
        if p.get("alive"):
            p["max_hp"]=p.get("base_hp", 150 if p.get("role")=="Tabib" else 100)
            p["hp"]=min(p.get("hp",p["max_hp"]),p["max_hp"])
    g["next_ability_swaps"]={}
    path=await night_image_path()
    if path:
        try:
            with open(path,'rb') as f: await app.bot.send_photo(g["chat_id"],InputFile(f),caption=f"🌙 <b>Tun {g['night']}</b> boshlandi.\nBarcha tungi harakatlar tongda birgalikda hal qilinadi.",parse_mode=ParseMode.HTML)
        except TelegramError: await app.bot.send_message(g["chat_id"],f"🌙 <b>Tun {g['night']}</b> boshlandi.",parse_mode=ParseMode.HTML)
    else: await app.bot.send_message(g["chat_id"],f"🌙 <b>Tun {g['night']}</b> boshlandi.",parse_mode=ParseMode.HTML)
    names="\n".join(f"• {html.escape(str(visible_name(g,p)))}" for p in living(g))
    await app.bot.send_message(g["chat_id"],f"👥 <b>Hozir tirik o‘yinchilar:</b>\n{names}",parse_mode=ParseMode.HTML)
    for p in living(g): await offer_night_action(app,g,p)
    if g.get("mode")=="zombie":
        app.job_queue.run_once(zombie_convert_job,max(0,NIGHT_TIME-5),data={"gid":g["id"]},name=f"zombie-convert-{g['id']}")
    schedule_phase(app,g,NIGHT_TIME,resolve_night,"night")
    persist_games()

async def offer_night_action(app,g,p):
    r=ability_role(p)
    if not p["alive"]: return
    if hero_row(p["id"]):
        await send_private(app.bot,p["id"],"🥷 Geroy harakati:",InlineKeyboardMarkup([[InlineKeyboardButton("👊 Hujum",callback_data=f"heroact:attack:{g['id']}:{p['id']}")],[InlineKeyboardButton("🛡 Himoyalanish",callback_data=f"heroact:shield:{g['id']}:{p['id']}")],[InlineKeyboardButton("⏭ O‘tkazib yuborish",callback_data=f"heroact:skip:{g['id']}:{p['id']}")]]))
    if r in {"Tinch axoli","Serjant","Suidsid","Kamikaze"}:
        if not (g.get("mode")=="zombie" and r=="Tinch axoli"): return
    if r=="Afsungar": return
    if g.get("mode")=="zombie" and r=="Zombi":
        await send_private(app.bot,p["id"],"🧟 Bugun kimni Zombi qilamiz?",name_buttons(g,"zombie",p["id"]))
        return
    if r=="Ruhoniy":
        dead=dead_targets(g)
        if not dead:
            await send_private(app.bot,p["id"],"✝️ Hozircha qaytariladigan o‘yinchi yo‘q.")
            return
        rows=[[InlineKeyboardButton(visible_name(g,x)[:32],callback_data=f"res:{g['id']}:{p['id']}:{x['id']}")] for x in dead]
        await send_private(app.bot,p["id"],"✝️ Bugun kimni qaytaramiz?",InlineKeyboardMarkup(rows)); return
    if r=="Professor":
        kb=InlineKeyboardMarkup([[InlineKeyboardButton("☠️ O‘lim qutisi",callback_data=f"prof:{g['id']}:{p['id']}:death")],[InlineKeyboardButton("💼 Oddiy yo‘l",callback_data=f"prof:{g['id']}:{p['id']}:normal")]])
        await send_private(app.bot,p["id"],"🎩 Bugun qaysi yo‘lni tanlaysiz?",kb); return
    if r=="Komissar Katani":
        kb=InlineKeyboardMarkup([[InlineKeyboardButton("🔎 Tekshirish",callback_data=f"katani_mode:{g['id']}:{p['id']}:check")],[InlineKeyboardButton("🔫 Nishonga olish",callback_data=f"katani_mode:{g['id']}:{p['id']}:kill")]])
        await send_private(app.bot,p["id"],"🕵🏻‍♂️ Bugun nima qilamiz?",kb); return
    if r=="Veyron":
        await send_private(app.bot,p["id"],"🧲 Magnitlash uchun kimni tanlaymiz?",name_buttons(g,"vey1",p["id"])) ; return
    texts={
        "Shifokor":"🩺 Bugun kimni davolaymiz?",
        "Daydi":"🌙 Bugun kimning derazasidan kuzatamiz?",
        "Kezuvchi":"🚶 Bugun kimni bloklaymiz?",
        "Koldun":"⚡ Bugun kimni tanlaymiz?",
        "Don":"🎩 Bugun kimni nishonga olamiz?",
        "Mafia":"🔪 Bugun kimni nishonga olamiz?",
        "Advokat":"⚖️ Bugun kimni himoya qilamiz?",
        "Ayg‘oqchi":"🕵️ Bugun kimni kuzatamiz?",
        "Labarant":"🧪 Bugun kimni nishonga olamiz?",
        "Manipulyator":"🪄 Bugun kimning harakatini o‘zgartiramiz?",
        "Ruhoniy":"✝️ Bugun kimni qaytarishga urinib ko‘ramiz?",
        "Undiruvchi":"💰 Bugun kimdan pul undiramiz?",
        "Sotqin":"🦎 Bugun kimni tanlaymiz?",
        "Folbin":"🧿 Bugun kimning tarafini aniqlaymiz?",
        "Zodagon":"👑 Bugun kimni tanlaymiz?",
        "La’natchi":"🕸️ Bugun kimni la’natlaymiz?",
        "Qotil":"🔪 Bugun kimni nishonga olamiz?",
        "Minior":"💣 Bugun kimni tanlaymiz?",
        "Snayper":"👨🏻‍🎤 Bugun kimni nishonga olamiz?",
        
        "Afsungar":"🧙‍♀️ Siz hujum bo‘lsa tongda qaror qilasiz.",
        "Qorbobo":"🎅 Bugun kimga sovg‘a beramiz? 🎁",
        "Qorbola":"🌨️ Bugun kimni Qorbo‘ron qilamiz?",
        "Tabib":"🩺 Bugun kimga dori qutisini beramiz?",
    }
    if r=="Afsungar": return
    await send_private(app.bot,p["id"],texts.get(r,"🎭 Bugun kimni tanlaymiz?"),name_buttons(g,"act",p["id"]))

# ---------------- CALLBACKS ----------------
def parse_target(data):
    a=data.split(":"); return a

async def cb_zombie(update,ctx):
    q=update.callback_query; a=q.data.split(":")
    if len(a)!=4: return
    _,gid,actor,target=a
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g.get("mode")!="zombie" or g["phase"]!="night": return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    if q.from_user.id!=int(actor): return await cb_answer(q,"Bu tanlov siz uchun emas.",True)
    p=getp(g,int(actor)); t=getp(g,int(target))
    if not p or p.get("role")!="Zombi" or not p["alive"] or not t or not t["alive"] or t["id"]==p["id"]: return await cb_answer(q,"Nishon mavjud emas.",True)
    if p.get("action") is not None: return await cb_answer(q,"Tanlovingiz allaqachon tasdiqlangan.",True)
    p["action"]={"type":"zombie","target":t["id"],"selected_at":time.time()}
    await safe_edit(q,f"🧟 Sizning tanlovingiz:\n\n{visible_name(g,t)}",None); await cb_answer(q,"Tanlov saqlandi.")

async def cb_res(update,ctx):
    q=update.callback_query; a=q.data.split(":")
    if len(a)!=4: return
    _,gid,uid,target=a
    g=next((x for x in games.values() if x.get("id")==gid),None)
    if not g or g.get("phase")!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    p=getp(g,int(uid)); t=getp(g,int(target))
    if not p or ability_role(p)!="Ruhoniy" or not p.get("alive") or p.get("resurrections",0)>=3 or not t or t.get("alive"): return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    if p.get("action") is not None: return await cb_answer(q,"Tanlovingiz allaqachon tasdiqlangan.",True)
    p["action"]={"type":"resurrect","target":t["id"],"selected_at":time.time()}
    await safe_edit(q,f"✝️ Sizning tanlovingiz:\n\n{visible_name(g,t,True)}",None); persist_games(); await cb_answer(q,"Tanlov saqlandi.")

async def cb_heroact(update,ctx):
    q=update.callback_query; a=q.data.split(":")
    if len(a)<4: return
    _,action,gid,uid=a
    g=next((x for x in games.values() if x.get("id")==gid),None)
    if not g or g.get("phase")!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    p=getp(g,int(uid)); h=hero_row(int(uid))
    if not p or not p.get("alive") or not h: return await cb_answer(q,"Geroy mavjud emas.",True)
    if p.get("hero_action") is not None: return await cb_answer(q,"Geroy tanlovi allaqachon saqlandi.",True)
    if action=="attack":
        if h["patron"]<1: return await cb_answer(q,"Geroyingizda zaryad qolmagan.",True)
        rows=[]
        for t in living(g):
            if t["id"]!=p["id"]: rows.append([InlineKeyboardButton(visible_name(g,t)[:32],callback_data=f"heroact:target:{gid}:{uid}:{t['id']}")])
        return await safe_edit(q,"👊 Geroy bilan kimga hujum qilamiz?",InlineKeyboardMarkup(rows))
    if action=="shield":
        p["hero_action"]={"type":"shield","selected_at":time.time()}
        return await safe_edit(q,"🥷 Geroy harakati:\n\nSizning tanlovingiz: 🛡 Himoyalanish",None)
    if action=="skip":
        p["hero_action"]={"type":"skip","selected_at":time.time()}
        return await safe_edit(q,"🥷 Geroy harakati:\n\nSizning tanlovingiz: ⏭ O‘tkazib yuborish",None)
    if action=="target" and len(a)==5:
        target=getp(g,int(a[4]))
        if not target or not target.get("alive") or target["id"]==p["id"]: return await cb_answer(q,"Nishon mavjud emas.",True)
        p["hero_action"]={"type":"attack","target":target["id"],"selected_at":time.time()}
        return await safe_edit(q,f"🥷 Geroy harakati:\n\nSizning tanlovingiz: 👊 {visible_name(g,target)}",None)
    return await cb_answer(q)

async def cb_action(update,ctx):
    q=update.callback_query; a=parse_target(q.data)
    if len(a)<4: return
    _,gid,actor,target=a[:4]
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g["phase"]!="night": return await cb_answer(q,"Bu tun tugagan.",True)
    if q.from_user.id!=int(actor): return await cb_answer(q,"Bu tanlov siz uchun emas.",True)
    p=getp(g,int(actor)); t=getp(g,int(target))
    if not p or not t or not p["alive"] or not t["alive"]: return await cb_answer(q,"O‘yinchi endi mavjud emas.",True)
    if p["action"] is not None: return await cb_answer(q,"Tanlovingiz allaqachon tasdiqlangan.",True)
    r=ability_role(p)
    if r=="Manipulyator":
        rows=[[InlineKeyboardButton(visible_name(g,x)[:32],callback_data=f"manip2:{gid}:{actor}:{x['id']}")] for x in living(g) if x["id"] not in {p["id"],t["id"]}]
        p["action"]={"type":"manipulator","controlled":t["id"],"selected_at":time.time()}
        await safe_edit(q,"🪄 Endi harakatni kimga yo‘naltiramiz?",InlineKeyboardMarkup(rows))
        persist_games(); return await cb_answer(q,"Birinchi tanlov saqlandi.")
    p["action"]={"type":"target","target":t["id"],"selected_at":time.time()}
    texts={"Shifokor":"🩺 Sizning tanlovingiz:","Daydi":"🌙 Sizning tanlovingiz:","Kezuvchi":"🚶 Sizning tanlovingiz:","Koldun":"⚡ Sizning tanlovingiz:","Don":"🎩 Sizning tanlovingiz:","Mafia":"🔪 Sizning tanlovingiz:","Advokat":"⚖️ Sizning tanlovingiz:","Ayg‘oqchi":"🕵️ Sizning tanlovingiz:","Labarant":"🧪 Sizning tanlovingiz:","Manipulyator":"🪄 Sizning tanlovingiz:","Ruhoniy":"✝️ Sizning tanlovingiz:","Undiruvchi":"💰 Sizning tanlovingiz:","Sotqin":"🦎 Sizning tanlovingiz:","Folbin":"🧿 Sizning tanlovingiz:","Zodagon":"👑 Sizning tanlovingiz:","Qotil":"🔪 Sizning tanlovingiz:","Minior":"💣 Sizning tanlovingiz:","Snayper":"👨🏻‍🎤 Sizning tanlovingiz:","Qorbobo":"🎅 Sizning tanlovingiz:","Qorbola":"🌨️ Sizning tanlovingiz:","Tabib":"🩺 Sizning tanlovingiz:"}
    await safe_edit(q,texts.get(r,"Sizning tanlovingiz:")+f"\n\n{visible_name(g,t)}",None)
    persist_games()
    await cb_answer(q,"Tanlov saqlandi.")

async def cb_manip2(update,ctx):
    q=update.callback_query; parts=q.data.split(":")
    if len(parts)!=4: return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    _,gid,uid,target=parts; g=find_game(gid)
    if not g or g.get("phase")!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tun tugagan.",True)
    p=getp(g,int(uid)); t=getp(g,int(target))
    if not p or not t or not p.get("alive") or not t.get("alive") or ability_role(p)!="Manipulyator": return await cb_answer(q,"Nishon mavjud emas.",True)
    a=p.get("action") or {}
    if a.get("type")!="manipulator" or a.get("redirect_target") is not None: return await cb_answer(q,"Tanlovingiz allaqachon saqlandi.",True)
    if t["id"] in {p["id"],a.get("controlled")}: return await cb_answer(q,"Bu o‘yinchini tanlab bo‘lmaydi.",True)
    a["redirect_target"]=t["id"]
    p["action"]=a
    await safe_edit(q, f"🪄 Sizning tanlovingiz:\n\n{visible_name(g,getp(g,a['controlled']))} → {visible_name(g,t)}", None)
    persist_games(); await cb_answer(q,"Tanlov saqlandi.")

async def cb_katani_mode(update,ctx):
    q=update.callback_query; a=q.data.split(":"); _,gid,uid,mode=a
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g["phase"]!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    p=getp(g,int(uid));
    if not p or not p.get("alive") or ability_role(p)!="Komissar Katani" or p["action"] is not None:return await cb_answer(q,"Tanlovingiz allaqachon saqlandi.",True)
    kb=[]
    for t in targets(g,p["id"]): kb.append([InlineKeyboardButton(visible_name(g,t)[:32],callback_data=f"katani:{gid}:{uid}:{t['id']}:{mode}")])
    await safe_edit(q,"🕵🏻‍♂️ Bugun kimni tanlaymiz?",InlineKeyboardMarkup(kb)); await cb_answer(q)

async def cb_katani(update,ctx):
    q=update.callback_query; _,gid,uid,target,mode=q.data.split(":")
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g["phase"]!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tun tugagan.",True)
    p=getp(g,int(uid)); t=getp(g,int(target))
    if not p or not t or not p.get("alive") or ability_role(p)!="Komissar Katani" or p["action"] is not None:return await cb_answer(q,"Tanlov saqlandi yoki mavjud emas.",True)
    p["action"]={"type":mode,"target":t["id"],"selected_at":time.time()}
    await safe_edit(q,"🕵🏻‍♂️ Sizning tanlovingiz:\n\n"+visible_name(g,t)+(" — 🔎 Tekshirish" if mode=="check" else " — 🔫 Nishonga olish"),None); await cb_answer(q,"Tanlov saqlandi.")

async def cb_prof(update,ctx):
    q=update.callback_query; parts=q.data.split(":")
    if len(parts)!=4: return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    _,gid,uid,choice=parts
    g=next((x for x in games.values() if x.get("id")==gid),None)
    if not g or g.get("phase")!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tun tugagan.",True)
    p=getp(g,int(uid));
    if not p or not p.get("alive") or ability_role(p)!="Professor" or p.get("action") is not None:
        return await cb_answer(q,"Tanlov saqlandi yoki mavjud emas.",True)
    if choice=="death":
        rows=[[InlineKeyboardButton(visible_name(g,t)[:32],callback_data=f"prof_target:{gid}:{uid}:{t['id']}")] for t in targets(g,p["id"])]
        if not rows: return await cb_answer(q,"Nishon yo‘q.",True)
        return await safe_edit(q,"🎩 O‘lim qutisi uchun nishonni tanlang.",InlineKeyboardMarkup(rows))
    p["action"]={"type":"professor","choice":"normal","selected_at":time.time()}
    await safe_edit(q,"🎩 Sizning tanlovingiz:\n💼 Oddiy yo‘l",None); await cb_answer(q,"Tanlov saqlandi.")

async def cb_prof_target(update,ctx):
    q=update.callback_query; parts=q.data.split(":")
    if len(parts)!=4: return await cb_answer(q,"Bu tanlov mavjud emas.",True)
    _,gid,uid,target=parts
    g=next((x for x in games.values() if x.get("id")==gid),None)
    if not g or g.get("phase")!="night" or q.from_user.id!=int(uid): return await cb_answer(q,"Bu tun tugagan.",True)
    p=getp(g,int(uid)); t=getp(g,int(target))
    if not p or not t or not p.get("alive") or not t.get("alive") or ability_role(p)!="Professor" or p.get("action") is not None:
        return await cb_answer(q,"Nishon mavjud emas.",True)
    p["action"]={"type":"professor","choice":"death","target":t["id"],"selected_at":time.time()}
    await safe_edit(q,f"🎩 Sizning tanlovingiz:\n☠️ O‘lim qutisi — {visible_name(g,t)}",None); persist_games(); await cb_answer(q,"Tanlov saqlandi.")

async def cb_vey1(update,ctx):
    q=update.callback_query; _,gid,uid,target=q.data.split(":")
    g=next((x for x in games.values() if x["id"]==gid),None)
    if not g or g["phase"]!="night" or q.from_user.id!=int(uid):return await cb_answer(q,"Bu tun tugagan.",True)
    p=getp(g,int(uid)); t=getp(g,int(target));
    if not p or not t or not p.get("alive") or ability_role(p)!="Veyron" or p["action"] is not None:return await cb_answer(q,"Tanlov mavjud emas.",True)
    p["action"]={"type":"veyron","first":t["id"],"selected_at":time.time()}
    rows=[[InlineKeyboardButton(visible_name(g,x)[:32],callback_data=f"vey2:{gid}:{uid}:{x['id']}" )] for x in living(g) if x["id"] not in {p["id"],t["id"]}]
    await safe_edit(q,"🧲 Ikkinchi o‘yinchini tanlang.",InlineKeyboardMarkup(rows)); await cb_answer(q)

async def cb_vey2(update,ctx):
    q=update.callback_query; _,gid,uid,target=q.data.split(":")
    g=next((x for x in games.values() if x["id"]==gid),None); p=getp(g,int(uid)) if g else None
    if not g or g["phase"]!="night" or q.from_user.id!=int(uid) or not p:return await cb_answer(q,"Bu tun tugagan.",True)
    if p["action"] is None or p["action"].get("type")!="veyron":return await cb_answer(q,"Birinchi tanlov topilmadi.",True)
    if p["action"].get("second"):return await cb_answer(q,"Tanlov saqlandi.",True)
    t=getp(g,int(target)); first=getp(g,p["action"]["first"])
    if not t or not first or not t["alive"] or t["id"] in {p["id"], first["id"]}:
        return await cb_answer(q,"Ikkinchi o‘yinchi mavjud emas.",True)
    p["action"]["second"]=t["id"]
    await safe_edit(q,f"🧲 Sizning tanlovingiz:\n\n{visible_name(g,first)} ↔ {visible_name(g,t)}",None)
    remaining=max(0,int(g.get("phase_ends_at",time.time())-time.time())-5)
    ctx.job_queue.run_once(veyron_notice_job,remaining,data={"gid":g["id"]},name=f"veyron-notice-{g['id']}-{uid}")
    persist_games(); await cb_answer(q,"Tanlov saqlandi.")

async def cb_menu(update,ctx):
    q=update.callback_query; await cb_answer(q)
    if q.message.chat.type!=ChatType.PRIVATE:return
    key=q.data.split(":",1)[1]
    if key=="home":
        me=await ctx.bot.get_me()
        await safe_edit(q,"🎭 <b>EPIC MAFIA</b>\n\nXush kelibsiz!",main_menu(me.username or ""))
    elif key=="profile":
        ensure_user(q.from_user)
        text=await build_profile_text(ctx.bot,q.from_user.id)
        await safe_edit(q,text,InlineKeyboardMarkup([[InlineKeyboardButton("🥷 Mening Geroyim",callback_data="menu:hero")],[InlineKeyboardButton("📊 Reyting",callback_data="menu:rating")],[InlineKeyboardButton("🛒 Do‘kon",callback_data="menu:market")],[InlineKeyboardButton("🔙 Orqaga",callback_data="menu:home")]]))
    elif key=="roles":
        await safe_edit(q,roles_menu_text(),roles_menu_markup())
    elif key=="hero": await show_hero(q,q.from_user.id)
    elif key=="rating":
        con=db(); rows=con.execute("SELECT first_name,wins,games,money FROM users ORDER BY wins DESC,games DESC LIMIT 10").fetchall(); con.close()
        lines=["🏆 <b>Epic Mafia reytingi</b>",""]
        for i,r in enumerate(rows,1): lines.append(f"{i}. {html.escape(str(r['first_name'] or 'Nomsiz'))} — 🏆 {r['wins']} / 🎮 {r['games']}")
        await safe_edit(q,"\n".join(lines),InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Orqaga",callback_data="menu:profile")]]))
    elif key=="market":
        ensure_user(q.from_user)
        await send_market(q.message)

async def cb_role(update,ctx):
    q=update.callback_query
    if q.message.chat.type != ChatType.PRIVATE:
        return await cb_answer(q,"Faqat shaxsiy chatda.",True)
    try:
        idx=int(q.data.split(":",1)[1])
        role=ROLES[idx]
    except (ValueError, IndexError):
        return await cb_answer(q,"Rol topilmadi.",True)
    await cb_answer(q)
    await safe_edit(q,role_detail_text(role),InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Orqaga",callback_data="menu:roles")]]))

async def cb_buy(update,ctx):
    q=update.callback_query; await cb_answer(q)
    if q.message.chat.type!=ChatType.PRIVATE:return
    uid=q.from_user.id; item=q.data.split(":")[1]
    mapping={"fake":("fake_document","money",200,"Soxta hujjat"),"protection":("protection","money",200,"Himoya"),"mask":("mask","diamonds",1,"Niqob"),"rifle":("rifle","diamonds",1,"Miltiq"),"hanging":("hanging_protection","diamonds",2,"Osilishdan himoya"),"supper":("supper_shield","diamonds",3,"Supper qalqon"),"hero_protection":("hero_protection","diamonds",HERO_PROTECTION_PRICE,"Geroydan himoya")}
    if item=="stats":
        con=db(); r=con.execute("SELECT money FROM users WHERE user_id=?",(uid,)).fetchone()
        if r and r[0]>=600: con.execute("UPDATE users SET money=money-600,wins=0,games=0 WHERE user_id=?",(uid,)); con.commit(); con.close(); return await cb_answer(q,"Statistika tiklandi✅",True)
        con.close(); return await cb_answer(q,"Sizda yetarli 💷 mavjud emas❌",True)
    if item=="active":
        ok,msg=buy(uid,"active_role","money",0)
        return await cb_answer(q,"Faol rol xarid qilindi✅",True)
    key,currency,cost,title=mapping[item]; ok,msg=buy(uid,key,currency,cost)
    await cb_answer(q,(f"{title} xarid qilindi✅" if ok else f"Sizda yetarli {'💎' if currency=='diamonds' else '💷'} mavjud emas❌"),True)

# ---------------- NIGHT RESOLUTION ----------------
def consume_inventory(p,key):
    d=inv(p["id"])
    if d.get(key,0)<=0:return False
    d[key]-=1
    if d[key]<=0: d.pop(key,None)
    set_inv(p["id"],d); return True

def bounty_killer(attacks, victim_id):
    """Return the earliest-selected attacker whose attack is recorded as a real candidate for the victim."""
    candidates=[]
    for actor,target,killer_role in attacks:
        if not target or target.get("id")!=victim_id or not actor or not killer_role:
            continue
        action=actor.get("action") or {}
        selected=action.get("selected_at", float("inf"))
        candidates.append((selected, actor))
    if not candidates: return None
    candidates.sort(key=lambda x:x[0])
    return candidates[0][1]

def zombie_mode_winner(players):
    alive=[p for p in players if p.get("alive")]
    z=sum(p.get("role")=="Zombi" for p in alive)
    h=len(alive)-z
    if z==0 or h==0:
        return [p for p in alive if (p.get("role")=="Zombi")== (z>0)]
    return []

def apply_protection(target, killer_role):
    if target["supper"]:
        target["supper"]=False; return "supper"
    if killer_role in {"Qotil","Snayper","Professor"}: return None
    if target["protection_used"]: return None
    if target["protected"]:
        target["protected"]=False; target["protection_used"]=True
        consume_inventory(target,"protection")
        return "protection"
    return None

def kill_player(p, reason=""):
    if not p["alive"]: return False
    p["alive"]=False; p["hp"]=0; return True

async def send_zombie_rosters(bot,g):
    zombies=[p for p in g.get("players",{}).values() if p.get("alive") and p.get("role")=="Zombi"]
    if not zombies: return
    text="🧟 <b>Zombie tarafidagi o‘yinchilar:</b>\n"+"\n".join(f"• {p['name']}" for p in zombies)
    for z in zombies:
        await send_private(bot,z["id"],text)

async def veyron_notice_job(ctx):
    d=ctx.job.data; g=next((x for x in games.values() if x.get("id")==d.get("gid")),None)
    if not g or g.get("phase")!="night": return
    for pair in g.get("veyron_notice", []):
        x=getp(g,pair.get("x")); y=getp(g,pair.get("y"))
        if x and y:
            await send_private(ctx.bot,x["id"],f"🧲 Keyingi tunda siz {role_label(y['role'])} qobiliyatidan foydalanasiz.")
            await send_private(ctx.bot,y["id"],f"🧲 Keyingi tunda siz {role_label(x['role'])} qobiliyatidan foydalanasiz.")
    g["veyron_notice"]=[]

async def zombie_convert_job(ctx):
    d=ctx.job.data; g=next((x for x in games.values() if x.get("id")==d.get("gid")),None)
    if not g or g.get("phase")!="night" or g.get("mode")!="zombie": return
    pending=g.get("mode_state",{}).get("zombie_pending") or []
    if not pending: return
    pending=sorted(pending,key=lambda x:x.get("selected_at",0))
    item=pending[0]; target=getp(g,item["target"])
    if not target or not target.get("alive") or target.get("role")=="Zombi": return
    target["role"]="Zombi"
    g["mode_state"]["zombie_ids"]=list(set(g["mode_state"].get("zombie_ids",[])+[target["id"]]))
    g["mode_state"]["zombie_pending"]=[]
    await send_private(ctx.bot,target["id"],"🧟 Siz Zombi bo‘ldingiz!\nEndi siz Zombi tarafida o‘ynaysiz va keyingi tundan Zombi harakatini bajarasiz.")
    await send_zombie_rosters(ctx.bot,g)
    persist_games()

