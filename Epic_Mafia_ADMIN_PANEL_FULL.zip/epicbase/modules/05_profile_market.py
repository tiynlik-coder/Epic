def main_menu(bot_username=""):
    # Private /start menu: only the requested navigation buttons.
    # Profile and Market remain available through the private command menu.
    rows=[]
    if bot_username:
        rows.append([InlineKeyboardButton("➕ Guruhga qo‘shish",url=f"https://t.me/{bot_username}?startgroup=true")])
    if EPIC_PREMIUM_URL:
        rows.append([InlineKeyboardButton("🌟 Premium guruhlar",url=EPIC_PREMIUM_URL)])
    else:
        rows.append([InlineKeyboardButton("🌟 Premium guruhlar",callback_data="menu:premium")])
    rows.append([InlineKeyboardButton("🎭 Rollar",callback_data="menu:roles")])
    support_btn = InlineKeyboardButton("🆘 Yordam",url=EPIC_SUPPORT_URL) if EPIC_SUPPORT_URL else InlineKeyboardButton("🆘 Yordam",callback_data="menu:help")
    channel_btn = InlineKeyboardButton("📡 Kanal",url=EPIC_CHANNEL_URL) if EPIC_CHANNEL_URL else InlineKeyboardButton("📡 Kanal",callback_data="menu:channel")
    rows.append([support_btn, channel_btn])
    return InlineKeyboardMarkup(rows)

START_PRIVATE_TEXT = (
    "<b>Salom! 👋</b>\n\n"
    "Men Epic mafiyaning rasmiy botiman. Do‘stlaringiz bilan mafiya o‘ynash uchun "
    "meni guruhingizga qo‘shing va <b>50 kishilik o‘yindan zavqlaning! 🎭</b>\n\n"
    "Meni <b>admin</b> qilganingizdan so‘ng o‘yinni boshlashingiz mumkin."
)

def roles_menu_markup():
    # All 30 canonical roles, two per row. Clicking a role edits the same message.
    rows=[]
    for i in range(0, len(ROLES), 2):
        pair=ROLES[i:i+2]
        rows.append([InlineKeyboardButton(f"{EMOJI.get(r, '🎭')} {r}", callback_data=f"role:{i+j}") for j,r in enumerate(pair)])
    rows.append([InlineKeyboardButton("🔙 Orqaga", callback_data="menu:home")])
    return InlineKeyboardMarkup(rows)

def roles_menu_text():
    return "🎭 <b>Rollar ro‘yxati:</b>\n\nKerakli rolni tanlang:"

def role_detail_text(role):
    # Role emoji is kept exactly from the canonical/old Epic Mafia role mapping.
    intro = ROLE_INTRO.get(role, "Bu rolning maxsus qobiliyati o‘yin davomida ishlaydi.")
    return f"{EMOJI.get(role, '🎭')} <b>{html.escape(role)}</b>\n\n{intro}"

def stylized_name(name: str) -> str:
    """Render Latin names in the requested bold-italic serif style."""
    upper = dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "𝑨𝑩𝑪𝑫𝑬𝑭𝑮𝑯𝑰𝑱𝑲𝑳𝑴𝑵𝑶𝑷𝑸𝑹𝑺𝑻𝑼𝑽𝑾𝑿𝒀𝒁"))
    lower = dict(zip("abcdefghijklmnopqrstuvwxyz", "𝒂𝒃𝒄𝒅𝒆𝒇𝒈𝒉𝒊𝒋𝒌𝒍𝒎𝒏𝒐𝒑𝒒𝒓𝒔𝒕𝒖𝒗𝒘𝒙𝒚𝒛"))
    return "".join(upper.get(ch, lower.get(ch, ch)) for ch in (name or "Nomsiz"))

def profile_text(uid):
    r=get_user(uid); d=inv(uid)
    name=stylized_name(str(r['first_name'] or 'Nomsiz')) if r else stylized_name('Nomsiz')
    lines=[
        f"<b>{html.escape(name)}</b>",
        "",
        f"💵 <b>Pullar:</b> {int(r['money'] or 0)}" if r else "💵 <b>Pullar:</b> 0",
        f"💎 <b>Olmos:</b> {int(r['diamonds'] or 0)}" if r else "💎 <b>Olmos:</b> 0",
        f"🪙 <b>Epic Coin:</b> {int(r['coins'] or 0)}" if r else "🪙 <b>Epic Coin:</b> 0",
        "",
        f"🛡 <b>Himoya:</b> {d.get('protection',0)}",
        f"📃 <b>Soxta Hujjat:</b> {d.get('fake_document',0)}",
        f"⚖️ <b>Osilishdan himoya:</b> {d.get('hanging_protection',0)}",
        f"🔰 <b>Supper qalqon:</b> {d.get('supper_shield',0)}",
        f"🔫 <b>Miltiq:</b> {d.get('rifle',0)}",
        f"💊 <b>Doridan himoya:</b> {d.get('medicine_protection',0)}",
        f"🎭 <b>Maska:</b> {d.get('mask',0)}",
        f"🖍️ <b>Geroydan himoya:</b> {d.get('hero_protection',0)}",
        "",
        f"🎲 <b>Barcha o‘yinlar:</b> {int(r['games'] or 0) if r else 0}",
        f"🎯 <b>G‘alaba:</b> {int(r['wins'] or 0) if r else 0}",
        "",
        f"🃏 <b>Faol rollar:</b> {d.get('active_role',0)}",
    ]
    return "\n".join(lines)

async def is_epic_channel_member(bot, user_id: int) -> bool:
    """Check @epicmafianews membership. Bot must be an admin/member of the channel."""
    try:
        m = await bot.get_chat_member("@epicmafianews", user_id)
        if m.status in {"creator", "administrator", "member"}:
            return True
        if m.status == "restricted" and getattr(m, "is_member", False):
            return True
        return False
    except TelegramError:
        # If Telegram cannot verify membership, do not falsely claim that the user is subscribed.
        return False

async def build_profile_text(bot, uid: int) -> str:
    text = profile_text(uid)
    if not await is_epic_channel_member(bot, uid):
        text += "\n\nKanalga obuna bo‘lsangiz sizga 2x mukofot beriladi!\nKanal @epicmafianews"
    return text

async def cmd_start(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_user: ensure_user(update.effective_user)
    if update.effective_chat.type == ChatType.PRIVATE and ctx.args:
        if await join_lobby_deeplink(update,ctx,ctx.args[0]):
            return
        if await join_vs_deeplink(update,ctx,ctx.args[0]):
            return
    if update.effective_chat.type in {ChatType.GROUP,ChatType.SUPERGROUP}:
        await update.message.reply_text("🤖 Epic Mafia bot ishlayapti. O‘yinni boshlash uchun /game yuboring.")
        return
    grant_first_start(update.effective_user.id)
    me=await ctx.bot.get_me()
    await update.message.reply_text(START_PRIVATE_TEXT,reply_markup=main_menu(me.username or ""),parse_mode=ParseMode.HTML)

async def cmd_profile(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.PRIVATE}: return
    ensure_user(update.effective_user)
    text = await build_profile_text(ctx.bot, update.effective_user.id)
    await update.message.reply_text(text,reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Orqaga",callback_data="menu:home")]]),parse_mode=ParseMode.HTML)

async def cmd_market(update:Update,ctx:ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type not in {ChatType.PRIVATE}: return
    ensure_user(update.effective_user)
    await send_market_reply(update.message)

MARKET_TEXT = (
    "🛒 <b>Nima sotib olamiz?</b>\n\n"
    "📃 <b>Soxta Hujjat</b>\nKimdir sizning rolingizni tekshirmoqchi bo‘lsa, soxta hujjatlar yordam berishi mumkin.\n\n"
    "🛡 <b>Himoya</b>\nBir marta hayotingizni saqlab qoladi.\n\n"
    "⚖️ <b>Osilishdan himoya</b>\nKun davomida sizni osishga hukm qilishsa, bir marta qutqaradi.\n\n"
    "🔰 <b>Supper qalqon</b>\nTungi hujumlardan himoyalanishga yordam beradi.\n\n"
    "🔫 <b>Miltiq</b>\nAyrim himoyalangan nishonlarga qarshi ishlatiladigan o‘yin buyumi.\n\n"
    "🎭 <b>Maska</b>\nBuni olsangiz, Daydi sizni tanib olishda niqoblangan rolni ko‘radi.\n\n"
    "🎭 <b>Faol rol</b>\nKeyingi o‘yin uchun faol rol olish imkonini beradi.\n\n"
    "📊 <b>Statistikani tiklash</b>\nG‘alaba va o‘yinlar statistikasini qayta tiklaydi."
)

def market_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📊 Statistikani tiklash — 600💷",callback_data="buy:stats")],
        [InlineKeyboardButton("📃 Soxta Hujjat — 200💷",callback_data="buy:fake")],
        [InlineKeyboardButton("🛡 Himoya — 200💷",callback_data="buy:protection")],
        [InlineKeyboardButton("⚖️ Osilishdan himoya — 2💎",callback_data="buy:hanging")],
        [InlineKeyboardButton("🔰 Supper qalqon — 3💎",callback_data="buy:supper")],
        [InlineKeyboardButton("🔫 Miltiq — 1💎",callback_data="buy:rifle")],
        [InlineKeyboardButton("🎭 Maska — 1💎",callback_data="buy:mask")],
        [InlineKeyboardButton("🎭 Faol rol",callback_data="buy:active")],
        [InlineKeyboardButton("🔙 Orqaga",callback_data="menu:home")],
    ])

async def send_market_reply(msg):
    await msg.reply_text(MARKET_TEXT,reply_markup=market_keyboard(),parse_mode=ParseMode.HTML)

async def send_market(msg):
    await msg.edit_text(MARKET_TEXT,reply_markup=market_keyboard(),parse_mode=ParseMode.HTML)

# ---------------- GAME START ----------------
