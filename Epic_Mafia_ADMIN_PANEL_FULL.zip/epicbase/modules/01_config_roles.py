# Epic Mafia Bot — final Pydroid 3 build
# python-telegram-bot 20+ / 22.x compatible
# No external server. SQLite + polling.

import os, sys, time, json, random, sqlite3, asyncio, logging, base64, html, math
from pathlib import Path
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputFile, BotCommand
from telegram.constants import ChatType, ParseMode
from telegram.error import TelegramError, BadRequest
from telegram.ext import (
    Application, ApplicationBuilder, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters
)
from telegram import BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats

# ---------------- CONFIG ----------------
LOBBY_TIME = 1800
NIGHT_TIME = 30
DISCUSSION_TIME = 60
VOTING_TIME = 30
MAX_PLAYERS = 50
MIN_PLAYERS = 4
ADMIN_ID = 5500951019
DB_FILE = Path(__file__).with_name("epic_mafia.db")
STATE_FILE = Path(__file__).with_name("epic_mafia_state.json")
NIGHT_IMAGE = Path(__file__).with_name("epic_mafia_night.png")
EPIC_CHANNEL_URL = "https://t.me/epicmafianews"
EPIC_SUPPORT_URL = "https://t.me/insitutdan"
EPIC_PREMIUM_URL = os.getenv("EPIC_PREMIUM_URL", "").strip()

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("epic_mafia")
_PRIVATE_SEND_LOCK = asyncio.Lock()
_PRIVATE_SEND_LAST = 0.0

# ---------------- ROLE POOL ----------------
# Fixed 30 role types. No role type is generated dynamically.
ROLES = [
    "Tinch axoli", "Shifokor", "Daydi", "Komissar Katani", "Kezuvchi",
    "Serjant", "Koldun", "Sotqin", "Folbin", "Zodagon",
    "Don", "Mafia", "Advokat", "Ayg‘oqchi", "Labarant", "Manipulyator",
    "Ruhoniy", "Undiruvchi",
    "Qotil", "Minior", "Snayper", "Suidsid", "La’natchi", "Professor",
    "Afsungar", "Kamikaze", "Veyron", "Qorbobo", "Qorbola", "Tabib",
]
TOWN = {"Tinch axoli", "Shifokor", "Daydi", "Komissar Katani", "Kezuvchi", "Serjant", "Koldun", "Sotqin", "Folbin", "Kamikaze"}
MAFIA = {"Don", "Mafia", "Advokat", "Ayg‘oqchi", "Labarant", "Manipulyator", "Ruhoniy", "Undiruvchi"}
SOLO = set(ROLES) - TOWN - MAFIA

EMOJI = {
    "Tinch axoli":"👤", "Shifokor":"🧑🏻‍⚕️", "Daydi":"👁", "Komissar Katani":"🕵🏻", "Kezuvchi":"💃🏻",
    "Serjant":"👮🏻‍♂️", "Koldun":"⚡", "Sotqin":"🦎", "Folbin":"🧿", "Zodagon":"👑", "La’natchi":"🕸️",
    "Don":"🤵🏻", "Mafia":"🧑🏻‍💼", "Advokat":"⚖️", "Ayg‘oqchi":"🦇", "Labarant":"🧪", "Manipulyator":"🪄",
    "Ruhoniy":"✝️", "Undiruvchi":"💰", "Qotil":"🔪", "Minior":"👣", "Snayper":"👨🏻‍🎤",
    "Suidsid":"🪢", "Professor":"🎩", "Afsungar":"🧙‍♀️", "Kamikaze":"💥",
    "Veyron":"🧲", "Qorbobo":"🎅", "Qorbola":"🌨️", "Tabib":"🩺", "Zombi":"🧟",
}

NIGHT_ACTIVE = TOWN | MAFIA | SOLO - {"Tinch axoli", "Serjant", "Suidsid", "Kamikaze"}
# Explicitly active with no action: Professor etc are in set; Afsungar reacts only.

HARMFUL_ACTION_ROLES = {"Don", "Mafia", "Labarant", "Qotil", "Minior", "Snayper", "Professor", "Komissar Katani", "Koldun", "Qorbola"}
ORDINARY_KILLERS = {"Don", "Mafia", "Labarant", "Qotil", "Qorbola"}
SPECIAL_KILLERS = {"Snayper", "Professor", "Minior"}

ROLE_INTRO = {
    "Tinch axoli": "Siz Tinch aholi tarafdasiz. Maxsus tungi harakatingiz yo‘q. Maqsadingiz — tirik qolib, Tinch aholi g‘alabasiga yordam berish.",
    "Shifokor": "Siz Tinch aholi tarafdasiz. Har tun bir o‘yinchini davolab, uni oddiy hujumdan saqlashga harakat qilasiz.",
    "Daydi": "Siz Tinch aholi tarafdasiz. Har tun bir uyni kuzatib, u yerga kelgan mehmonlarni aniqlaysiz.",
    "Komissar Katani": "Siz Tinch aholi tarafdasiz. Har tun tekshirish yoki nishonga olishdan birini tanlaysiz.",
    "Kezuvchi": "Siz Tinch aholi tarafdasiz. Har tun bir o‘yinchini kuzatib, uning tungi harakatini bloklaysiz.",
    "Serjant": "Siz Tinch aholi tarafdasiz. Komissar Katani o‘lsa, siz Komissar Kataniga aylanasiz va uning vazifalarini davom ettirasiz.",
    "Koldun": "Siz Tinch aholi tarafdasiz. Har tun bir o‘yinchini tanlaysiz: Tinch aholi bo‘lsa, kunduzgi osilishdan himoya qilasiz; boshqa taraf bo‘lsa, unga chaqmoq hujumi qilasiz.",
    "Sotqin": "Siz Tinch aholi tarafdasiz. Har tun bir o‘yinchini tekshirasiz. Zararli faoliyat aniqlansa, tongda bu haqda ma’lumot ochiladi.",
    "Folbin": "Siz Tinch aholi tarafdasiz. Har tun bir o‘yinchining qaysi tarafga mansubligini aniqlaysiz.",
    "Zodagon": "Siz Tinch aholi tarafdasiz. Har tun bir o‘yinchini tanlaysiz: tanlovingizga qarab unga yashirin tarzda tasodifiy pul beriladi.",
    "Don": "Siz Mafia tarafdasiz. Mafia jamoasining asosiy tungi nishonini belgilaysiz.",
    "Mafia": "Siz Mafia tarafdasiz. Mafia jamoasining tungi hujumida qatnashasiz.",
    "Advokat": "Siz Mafia tarafdasiz. Har tun bir o‘yinchini himoya qilib, ayrim tekshiruvlarning natijasini o‘zgartira olasiz.",
    "Ayg‘oqchi": "Siz Mafia tarafdasiz. Har tun tanlangan o‘yinchi haqida yashirin ma’lumot to‘playsiz.",
    "Labarant": "Siz Mafia tarafdasiz. Har tun o‘ziga xos hujum/ta’sir qobiliyatingizdan foydalanasiz.",
    "Manipulyator": "Siz Mafia tarafdasiz. Har tun boshqa o‘yinchining harakatini o‘zgartirishga urinishingiz mumkin.",
    "Ruhoniy": "Siz Mafia tarafdasiz. Tunda o‘lgan o‘yinchini qaytarishga urinishingiz mumkin. Sizda cheklangan miqdorda qayta tiriltirish imkoniyati bor.",
    "Undiruvchi": "Siz Mafia tarafdasiz. Har tun tanlangan o‘yinchidan pul undirishga harakat qilasiz.",
    "Qotil": "Siz Yakka tarafdasiz. Har tun bir o‘yinchini nishonga olib, uni o‘ldirishga harakat qilasiz.",
    "Minior": "Siz Yakka tarafdasiz. Siz portlovchi hujumga ega bo‘lgan maxsus rol sifatida tunda nishon tanlaysiz.",
    "Snayper": "Siz Yakka tarafdasiz. Sizning maxsus o‘qingiz ayrim oddiy himoyalardan ta’sirlanmaydi.",
    "Suidsid": "Siz Yakka tarafdasiz. Faqat kunduzgi ovoz berishda osilganingizda g‘alaba qozonasiz.",
    "La’natchi": "Siz Yakka tarafdasiz. Har tun bir o‘yinchini la’natlaysiz; agar u o‘sha tun haqiqiy o‘ldirishga sabab bo‘lsa, la’nat ta’sir qiladi.",
    "Professor": "Siz Yakka tarafdasiz. Har tun maxsus yo‘llardan birini tanlaysiz; o‘lim qutisini tanlash alohida xavfli ta’sirga ega.",
    "Afsungar": "Siz hech bir tarafga bo‘ysunmaysiz. Tunda sizga hujum qilinsa, hujum qilganlarning taqdirini o‘zingiz hal qilasiz. Maqsadingiz — tirik qolish.",
    "Kamikaze": "Siz Tinch aholi tarafdasiz. Sizni o‘ldirgan hujumchiga qarshi o‘ziga xos qasos imkoniyatingiz bor. Shartlar bajarilsa, mustaqil ravishda ham g‘alaba qozonasiz.",
    "Veyron": "Siz Yakka tarafdasiz. Har tun ikki o‘yinchini tanlab, ularning qobiliyatlarini keyingi tun uchun almashtirasiz. Rollari va taraflari o‘zgarmaydi.",
    "Qorbobo": "Siz Yakka tarafdasiz. Har tun bir tirik o‘yinchiga bot tasodifiy tanlagan sovg‘ani berasiz.",
    "Qorbola": "Siz Yakka tarafdasiz. Har tun bir o‘yinchini tanlab, unga Qorbo‘ron yuborib o‘ldirishga harakat qilasiz.",
    "Tabib": "Siz Yakka tarafdasiz. Har tun bir o‘yinchini tanlab, unga shu tun uchun +50 HP berasiz. Maqsadingiz — tirik qolish.",
}


# ---------------- DB ----------------
