def _json_game(g):
    out=dict(g)
    out.pop("jobs", None)
    out["players"]={str(uid):dict(p) for uid,p in g.get("players",{}).items()}
    return out

def persist_games():
    try:
        STATE_FILE.write_text(json.dumps({str(cid):_json_game(g) for cid,g in games.items() if g.get("phase") not in {"ended","cancelled"}}, ensure_ascii=False), encoding="utf-8")
    except Exception:
        log.exception("state save failed")

def load_games_state():
    if not STATE_FILE.exists(): return
    try:
        raw=json.loads(STATE_FILE.read_text(encoding="utf-8"))
        for cid,g in raw.items():
            g["chat_id"]=int(cid); g["players"]={int(uid):p for uid,p in g.get("players",{}).items()}
            g["jobs"]=[]; g.setdefault("next_ability_swaps",{}); g.setdefault("veyron_notice",[]); g.setdefault("bounties",[])
            for p in g["players"].values():
                p.setdefault("base_hp",150 if p.get("role")=="Tabib" else 100); p.setdefault("temp_hp_bonus",0); p.setdefault("last_attackers",[])
                p.setdefault("hero_action",None); p.setdefault("afsungar_decisions",{}); p.setdefault("advokat_result",False); p.setdefault("team",None)
            games[int(cid)]=g
    except Exception:
        log.exception("state restore failed")

def resume_games(app):
    now=time.time()
    for g in list(games.values()):
        phase=g.get("phase")
        if phase in {"ended","cancelled","starting"}: continue
        remaining=max(0,int(g.get("phase_ends_at",now)-now))
        if phase=="lobby": fn=finish_lobby; name="lobby-resume"
        elif phase=="night": fn=resolve_night; name="night-resume"
        elif phase=="discussion": fn=start_voting; name="discussion-resume"
        elif phase=="afsungar": fn=resolve_afsungar; name="afsungar-resume"
        elif phase=="voting": fn=resolve_vote; name="vote-resume"
        else: continue
        cancel_jobs(g)
        g["jobs"]=[app.job_queue.run_once(fn,remaining,data={"gid":g["id"],"phase":g["phase_id"]},name=f"{name}-{g['id']}")]
        if phase=="night" and g.get("mode")=="zombie" and g.get("mode_state",{}).get("zombie_pending"):
            rem_to_dawn=max(0,int(g.get("phase_ends_at",now)-now)-5)
            app.job_queue.run_once(zombie_convert_job,max(0,rem_to_dawn),data={"gid":g["id"]},name=f"zombie-resume-{g['id']}")
        if phase=="night" and g.get("veyron_notice"):
            rem_to_notice=max(0,int(g.get("phase_ends_at",now)-now)-5)
            app.job_queue.run_once(veyron_notice_job,max(0,rem_to_notice),data={"gid":g["id"]},name=f"veyron-resume-{g['id']}")

# Role balance: no new role types. At 30 players all 30 role types appear once.
# For smaller lobbies, use a deterministic faction-balanced subset; above 30 repeat roles.
def role_balance(n):
    mafia = max(1, min(8, round(n*0.27)))
    town = max(2, round(n*0.43))
    solo = n-mafia-town
    if solo<0: solo=0; town=n-mafia
    # Guarantee the main information role at normal sizes.
    town_roles=["Komissar Katani","Shifokor","Daydi","Kezuvchi","Serjant","Koldun","Sotqin","Folbin","Tinch axoli","Kamikaze"]
    mafia_roles=["Don","Mafia","Advokat","Ayg‘oqchi","Labarant","Manipulyator","Ruhoniy","Undiruvchi"]
    solo_roles=[r for r in ROLES if r not in TOWN and r not in MAFIA]
    out=[]
    if n>=4:
        # Main role guarantees without exceeding faction targets.
        if town>=1: out.append("Komissar Katani")
        if town>=2: out.append("Shifokor")
        while sum(1 for r in out if r in TOWN)<town:
            pool=[r for r in town_roles if r not in out]
            if not pool: pool=["Tinch axoli"]
            out.append(random.choice(pool))
    out += random.sample(mafia_roles, min(mafia,len(mafia_roles)))
    while sum(1 for r in out if r in MAFIA)<mafia: out.append(random.choice(mafia_roles))
    out += random.sample(solo_roles, min(solo,len(solo_roles)))
    while sum(1 for r in out if r in SOLO):
        if len(out)>=n: break
        out.append(random.choice(solo_roles))
    while len(out)<n:
        out.append("Tinch axoli")
    random.shuffle(out)
    return out[:n]

def new_player(u):
    ensure_user(u)
    return {
        "id":u.id,"name":u.first_name or u.username or str(u.id),"username":u.username or "",
        "role":None,"alive":True,"hp":100,"max_hp":100,
        "protected":False,"protection_used":False,"hanging_protected":False,"supper":False,
        "mask":False,"fake_document":False,"rifle":False,"active_role":False,
        "blocked":False,"action":None,"visits":[],"inactive":0,"resurrections":0,
        "prof_box":None,"prof_bonus":0,"manipulations":0,"kamikaze_used":False,
        "afsungar_decisions":{},"temp_ability":None,"temp_from":None,"base_hp":100,"temp_hp_bonus":0,"last_attackers":[],"team":None,
    }

def mention(p):
    name=html.escape(str(p.get("name") or "O‘yinchi"))
    return f'<a href="tg://user?id={p["id"]}">{name}</a>'

def side(r):
    if r == "Zombi": return "Zombi"
    return "Tinch" if r in TOWN else "Mafia" if r in MAFIA else "Yakka"
def living(g): return [p for p in g["players"].values() if p["alive"]]
def getp(g,uid): return g["players"].get(uid)
def targets(g,uid=None): return [p for p in living(g) if p["id"]!=uid]
def dead_targets(g): return [p for p in g["players"].values() if not p["alive"]]
def role_label(r): return f"{EMOJI.get(r, '🧟' if r == "Zombi" else '🎭')} {r}"

def ability_role(p):
    """Role ability currently granted to the player for this night."""
    return p.get("temp_ability") or p.get("role")

VS_TEAM_COLORS = {
    "red":"🔴", "blue":"🔵", "green":"🟢", "yellow":"🟡",
    "purple":"🟣", "orange":"🟠", "black":"⚫", "white":"⚪", "brown":"🟤",
}

def team_icon(p):
    return VS_TEAM_COLORS.get(p.get("team"), "") if p else ""

def visible_name(g, p, reveal=False):
    if not p: return "O‘yinchi"
    if g.get("mode") == "name" and not reveal:
        base = g.get("mode_value") or "1"
    else:
        base = p["name"]
    if g.get("mode") == "vs" and p.get("team"):
        return f"{team_icon(p)} {base}"
    return base

def visible_mention(g, p, reveal=False):
    if g.get("mode") == "name" and not reveal:
        base = html.escape(str(visible_name(g,p,reveal)))
        return base
    m = mention(p)
    if g.get("mode") == "vs" and p.get("team"):
        return f"{team_icon(p)} {m}"
    return m

def alive_counts(g):
    t=[p for p in living(g) if p["role"] in TOWN]; m=[p for p in living(g) if p["role"] in MAFIA]; s=[p for p in living(g) if p["role"] in SOLO]
    return t,m,s

def role_lists(g):
    if g.get("mode")=="zombie":
        # Zombie mode hides every living role; Zombies participate in the day like everyone else.
        alive=living(g)
        return ("🟢 Tinch aholi ["+str(len(alive))+"]", "", "")
    t,m,s=alive_counts(g)
    def rl(p):
        prefix = team_icon(p) + " " if g.get("mode") == "vs" and p.get("team") else ""
        return prefix + role_label(p["role"])
    return ("🟢 Tinch aholi ["+str(len(t))+"]\n"+"\n".join(rl(p) for p in t) if t else "🟢 Tinch aholi [0]",
            "🔴 Mafia ["+str(len(m))+"]\n"+"\n".join(rl(p) for p in m) if m else "🔴 Mafia [0]",
            "🟣 Yakkalar ["+str(len(s))+"]\n"+"\n".join(rl(p) for p in s) if s else "🟣 Yakkalar [0]")

def game_id(): return f"{time.time_ns()}-{random.randrange(1000,9999)}"

# ---------------- VICTORY ----------------
def winners(g):
    ps=living(g); alive_roles=[p["role"] for p in ps]
    result=[]
    if g.get("mode") == "vs" and ps:
        teams={p.get("team") for p in ps if p.get("team")}
        if len(teams) == 1:
            winning_team=next(iter(teams))
            return [p for p in ps if p.get("team") == winning_team]
    # Suidsid only wins by hanging; handled in resolve_vote.
    if ps and all(r in MAFIA for r in alive_roles): result += [p for p in ps if p["role"] in MAFIA]
    elif not any(r in MAFIA for r in alive_roles) and not any(r in TOWN for r in alive_roles):
        result += ps
    elif not any(r in MAFIA for r in alive_roles) and all(p["role"] in TOWN for p in ps):
        result += ps
    # Standard Town victory: no Mafia alive, unless a hostile solo remains.
    if not any(p["role"] in MAFIA for p in ps) and ps:
        hostile=[p for p in ps if p["role"] in SOLO and p["role"] not in {"Kamikaze"}]
        if not hostile: result += [p for p in ps if p["role"] in TOWN]
    # Survival solos individually win if alive at a terminal state.
    for p in ps:
        if p["role"] in {"Afsungar","Veyron","Tabib","Qorbobo","Qorbola","Professor","Minior","Snayper","Qotil"}:
            if p not in result: result.append(p)
    # Mafia terminal state.
    if len([p for p in ps if p["role"] in MAFIA])>0 and not any(p["role"] in TOWN for p in ps) and not any(p["role"] in SOLO for p in ps):
        result=[p for p in ps if p["role"] in MAFIA]
    uniq=[]; seen=set()
    for p in result:
        if p["id"] not in seen: uniq.append(p); seen.add(p["id"])
    return uniq

def game_over(g):
    ps=living(g)
    if not ps: return True
    if g.get("mode") == "uniform":
        return len(ps) <= 1
    if g.get("mode") == "vs":
        teams={p.get("team") for p in ps if p.get("team")}
        return len(teams) <= 1
    if g.get("mode") == "zombie":
        zombies=[p for p in ps if p.get("role")=="Zombi"]
        humans=[p for p in ps if p.get("role")!="Zombi"]
        return not zombies or not humans
    mafia=sum(p["role"] in MAFIA for p in ps)
    town=sum(p["role"] in TOWN for p in ps)
    if mafia==0:
        return not any(p["role"] in SOLO for p in ps if p["role"] not in {"Kamikaze"})
    if town==0:
        return not any(p["role"] in SOLO for p in ps)
    return False

# ---------------- TELEGRAM HELPERS ----------------
async def safe_edit(q, text, markup=None):
    try:
        await q.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.HTML)
    except BadRequest as e:
        if "Message is not modified" not in str(e): log.debug("edit: %s",e)
    except TelegramError as e: log.warning("edit failed: %s",e)

async def cb_answer(q, text=None, alert=False):
    try: await q.answer(text or "", show_alert=alert)
    except TelegramError: pass

async def send_private(bot, uid, text, markup=None):
    global _PRIVATE_SEND_LAST
    try:
        async with _PRIVATE_SEND_LOCK:
            wait=max(0.0,0.04-(time.monotonic()-_PRIVATE_SEND_LAST))
            if wait: await asyncio.sleep(wait)
            result=await bot.send_message(uid,text,reply_markup=markup,parse_mode=ParseMode.HTML)
            _PRIVATE_SEND_LAST=time.monotonic()
            return result
    except TelegramError as e:
        log.info("private send failed uid=%s: %s",uid,e); return None

def name_buttons(g, prefix, uid, allow_self=False):
    rows=[]
    for p in living(g):
        if not allow_self and p["id"]==uid: continue
        rows.append([InlineKeyboardButton(visible_name(g,p)[:32],callback_data=f"{prefix}:{g['id']}:{uid}:{p['id']}")])
    return InlineKeyboardMarkup(rows)

async def night_image_path():
    if NIGHT_IMAGE.exists(): return NIGHT_IMAGE
    try:
        from PIL import Image, ImageDraw, ImageFont
        im=Image.new("RGB",(900,500),(7,11,28)); d=ImageDraw.Draw(im)
        # simple reusable night-city artwork
        for x,h in [(40,180),(150,260),(290,210),(410,330),(560,230),(690,290),(800,190)]:
            d.rectangle((x,500-h,x+80,500),fill=(18,25,50))
            for yy in range(500-h+25,470,35):
                for xx in range(x+12,x+70,25): d.rectangle((xx,yy,xx+8,yy+12),fill=(160,150,80))
        d.ellipse((700,55,790,145),fill=(235,235,205))
        d.text((35,25),"EPIC MAFIA • NIGHT",fill=(240,240,240))
        im.save(NIGHT_IMAGE)
    except Exception:
        return None
    return NIGHT_IMAGE

# ---------------- PHASE CONTROL ----------------
def cancel_jobs(g):
    for job in g.get("jobs",[]):
        try: job.schedule_removal()
        except Exception: pass
    g["jobs"]=[]

def schedule_phase(app,g,seconds,fn,name):
    cancel_jobs(g)
    phase=g["phase_id"]
    job=app.job_queue.run_once(fn,seconds,data={"gid":g["id"],"phase":phase},name=name)
    g["jobs"]=[job]; g["phase_ends_at"]=time.time()+seconds

def find_game(gid):
    return next((x for x in games.values() if x.get("id")==gid), None)

def valid_job(g,job): return bool(g) and job.get("phase")==g.get("phase_id")

# ---------------- LOBBY ----------------
def lobby_markup(g, bot_username=None):
    # Standard lobby: one button only. It opens the bot private chat via a deep link.
    if g.get("mode") == "vs" and bot_username:
        teams=int(g.get("mode_state",{}).get("teams_count",2))
        names=list(VS_TEAM_COLORS.keys())[:max(2,min(9,teams))]
        return InlineKeyboardMarkup([[InlineKeyboardButton(VS_TEAM_COLORS[n], url=f"https://t.me/{bot_username}?start=vsgame_{g['id']}_{n}") for n in names[i:i+3]] for i in range(0,len(names),3)])
    if bot_username:
        return InlineKeyboardMarkup([[InlineKeyboardButton("👨‍💼 Qo‘shilish",url=f"https://t.me/{bot_username}?start=join_{g['chat_id']}_{g['id']}")]])
    return InlineKeyboardMarkup([[InlineKeyboardButton("👨‍💼 Qo‘shilish",callback_data=f"join:{g['id']}")]])

def lobby_player_list(g):
    players=list(g.get("players",{}).values())
    if not players:
        return ""
    lines=["", "👥 <b>O‘yinchilar:</b>"]
    for i,p in enumerate(players,1):
        lines.append(f"{i}. {mention(p)}")
    return "\n".join(lines)

def standard_lobby_text(g):
    return "📌 <b>Ro‘yxatdan o‘tish boshlandi!</b>\n\n⏳ Ro‘yxatdan o‘tish: <b>30 daqiqa</b>" + lobby_player_list(g)

def vs_lobby_text(g):
    teams={k:[] for k in list(VS_TEAM_COLORS.keys())[:int(g.get("mode_state",{}).get("teams_count",2))]}
    for p in g.get("players",{}).values():
        if p.get("team") in teams:
            teams[p["team"]].append(visible_mention(g,p,True))
    lines=["⚔️ <b>VS mode</b>", "", "<b>Jamoalar:</b>"]
    for k, members in teams.items():
        lines.append(f"{VS_TEAM_COLORS[k]} <b>{k.title()}</b>")
        lines.extend(f"  {i}. {m}" for i,m in enumerate(members,1))
        if not members: lines.append("  —")
    lines += ["", f"Jami: <b>{len(g.get('players',{}))}</b>/{MAX_PLAYERS}", "⏳ Ro‘yxatdan o‘tish: 30 daqiqa"]
    return "\n".join(lines)

async def group_return_url(bot, g):
    """Build a button that returns the user to the exact lobby group."""
    try:
        chat=await bot.get_chat(g["chat_id"])
        if chat.username:
            return f"https://t.me/{chat.username}"
        # Supergroup message links are exact and do not require the group to be public.
        cid=str(g["chat_id"])
        if cid.startswith("-100") and g.get("lobby_message_id"):
            return f"https://t.me/c/{cid[4:]}/{g['lobby_message_id']}"
        # Fallback: a fresh invite to the exact group.
        inv=await bot.create_chat_invite_link(g["chat_id"], name="Epic Mafia lobby")
        return inv.invite_link
    except TelegramError:
        return ""

async def join_lobby_deeplink(update:Update,ctx:ContextTypes.DEFAULT_TYPE,token_value:str):
    parts=token_value.split("_",2)
    if len(parts)!=3 or parts[0]!="join":
        return False
    try:
        chat_id=int(parts[1]); gid=parts[2]
    except ValueError:
        return False
    g=games.get(chat_id)
    if not g or g.get("id")!=gid or g.get("phase")!="lobby":
        await update.message.reply_text("❌ Bu lobby topilmadi yoki ro‘yxatdan o‘tish yopilgan.")
        return True
    user=update.effective_user
    uid=user.id
    ensure_user(user)
    if uid not in g["players"]:
        if len(g["players"])>=MAX_PLAYERS:
            await update.message.reply_text("❌ O‘yin 50 kishiga to‘ldi.")
            return True
        g["players"][uid]=new_player(user)
        g["players"][uid]["lobby_joined_at"]=time.time()
        persist_games()
        me=await ctx.bot.get_me()
        try:
            await ctx.bot.edit_message_text(g["chat_id"],g["lobby_message_id"],standard_lobby_text(g),reply_markup=lobby_markup(g,me.username or ""),parse_mode=ParseMode.HTML)
        except TelegramError:
            pass
    return_url=await group_return_url(ctx.bot,g)
    kb=InlineKeyboardMarkup([[InlineKeyboardButton("↗️ Guruhga o‘tish",url=return_url)]]) if return_url else None
    await update.message.reply_text("<b>Siz o‘yinga muvaffaqiyatli qo‘shildingiz! 🎭</b>",reply_markup=kb,parse_mode=ParseMode.HTML)
    return True

async def create_lobby(update, ctx, mode=None, mode_value=None):
    if update.effective_chat.type not in {ChatType.GROUP,ChatType.SUPERGROUP}: return
    chat=update.effective_chat
    if chat.id in games and games[chat.id].get("phase") not in {"ended","cancelled"}:
        return await update.message.reply_text("⚠️ Bu guruhda allaqachon o‘yin/lobby mavjud.")
    gid=game_id()
    g={"id":gid,"chat_id":chat.id,"phase":"lobby","phase_id":1,"created":time.time(),"players":{},"jobs":[],"start_time":None,"night":0,"night_log":[],"votes":{},"lobby_message_id":None,"ended":False,"night_message_ids":[],"mode":mode,"mode_value":mode_value,"bounties":[],"mode_state":{}}
    if mode == "vs":
        g["mode_state"]={"teams_count":int(mode_value or 2)}
    games[chat.id]=g
    me=await ctx.bot.get_me()
    if mode == "vs":
        text=vs_lobby_text(g)
    elif mode:
        title={"name":"🏷️ Name mode","uniform":"🎭 Uniform mode","zombie":"🧟 Zombie mode"}.get(mode,"🎭 Epic Mafia")
        text=f"📌 <b>Ro‘yxatdan o‘tish boshlandi!</b>\n\n{title}"
    else:
        text=standard_lobby_text(g)
    msg=await update.message.reply_text(text,reply_markup=lobby_markup(g,me.username or ""),parse_mode=ParseMode.HTML)
    g["lobby_message_id"]=msg.message_id
    # Pin the registration message like the reference lobby.
    try:
        await ctx.bot.pin_chat_message(chat.id,msg.message_id,disable_notification=True)
    except TelegramError:
        pass
    persist_games()
    schedule_phase(ctx.application,g,LOBBY_TIME,finish_lobby,"lobby")

